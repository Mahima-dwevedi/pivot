<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchBank */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Manage Equipments';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="pull-right margin_top20 mobile_margin">
    <?= Html::a('Add Equipment to Field', ['create'], ['class' => 'btn btn-success']) ?>
    
</div>
<div class="user-index">

    <div id="margin_mobile" class="page-header">
        <div class="pull-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>          
    </div>
    <div class="breadcrumbs">
        <ul>
            <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
            <li><span class="readcrum_without_link">Manage Equipments</span></li>
        </ul>
        <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
    </div>

    <div class="row-fluid">
        <?php \yii\widgets\Pjax::begin(['id' => 'equipment-grid']); ?>   
        <div class="breadcrumbs" id="breadcrumbs-msg">

            <?php if ((Yii::$app->session->hasFlash('create')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active'))) { ?>
                <ul>
                    <?php
                    if (Yii::$app->session->getFlash('create')) {
                        echo '<li><span class="readcrum_without_link_success">' . ADD_EQUIPMENT_SUCCESS . '</li>';
                    } else if (Yii::$app->session->getFlash('update')) {
                        echo '<li><span class="readcrum_without_link_success">' . EDIT_EQUIPMENT_SUCCESS . '</li>';
                    } else if (Yii::$app->session->getFlash('delete')) {
                        echo '<li><span class="readcrum_without_link_success">' . DELETE_EQUIPMENT_SUCCESS . '</li>';
                    } else if (Yii::$app->session->getFlash('error')) {
                        echo '<li><span class="readcrum_without_link_success">' . ERROR_EQUIPMENT_SUCCESS . '</li>';
                    }
                    ?>						
                </ul>
            <?php }
            ?>
        </div>
        <div class="search-form">
            <?php echo $this->render('_search', ['model' => $searchModel]); ?>
        </div><!-- search-form -->
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-reorder"></i> All Equipment Details</h3>
                <!--<a class="btn pull-right" data-toggle="modal" href="#" id = "viewAll">View All</a>-->
            </div>
            <div class="clear"></div>

            <div class="box-content nopadding">
                <?php \yii\widgets\Pjax::begin(); ?>   
                <form action="" name='equipment-grid-list-form' id='equipment-grid-list-form'>
                    <div class="table-responsive">
                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'id' => 'equipment-grid',
                            'columns' => [

                                ['class' => 'yii\grid\SerialColumn'],
                                [
                                    'attribute' => 'fieldName',
                                    'label' => 'Field Name',
                                    'value' => function ($data) {
                                        if (isset($data->fkFieldID) && $data->fkFieldID != '') {
                                            if (is_object($data->field))
                                                $name = $data->field->fieldName;
                                            else
                                                $name = 'Not assigned';
                                        }
                                        else {
                                            $name = $data->fkFieldID;
                                        }
                                        return $name; // $data['name'] for array data, e.g. using SqlDataProvider.
                                    },
                                ],
                                [
                                    'attribute' => 'EquipmentType',
                                    'label' => 'Equipment Type',
                                    'value' => function ($data) {
                                        return Yii::$app->params['EquipmentType'][$data->EquipmentType]; // $data['name'] for array data, e.g. using SqlDataProvider.
                                    },
                                ],
                                [
                                    'attribute' => 'EquipmentName',
                                    'label' => 'Equipment Name',
                                    'value' => function ($data) {
                                        return $data->EquipmentName; // $data['name'] for array data, e.g. using SqlDataProvider.
                                    },
                                ],

                                [
                                    'attribute' => 'EqpCreatedDate',
                                    'label' => 'Created Date',
                                    'format' => 'raw',
                                    'value' => function ($data) {
                                        return date("m-d-Y", strtotime($data->EqpCreatedDate));  // $data['name'] for array data, e.g. using SqlDataProvider.
                                    },
                                ],
                                [
                                    'attribute' => 'PivotStopAction',
                                    'label' => 'Current State',
                                    'value' => function ($data) {
                                        if (isset($data->EqpStatus) && $data->EqpStatus != '') {
                                            return $data->EqpStatus == 1 ? 'Started' : 'Stopped';
                                        } else {
                                            $name = "Not Yet Started";
                                        }return $name;
                                    }
                                ],

                                [
                                    'header' => 'Action',
                                    'class' => 'yii\grid\ActionColumn',
                                    'template' => '{update} &nbsp;&nbsp;&nbsp; {delete}',
                                    'buttons' => [
                                        'delete' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon icon-trash my_font_icon"></span>', $url, [
                                                        'title' => Yii::t('app', 'delete'), 'data-pjax' => '0', 'data-confirm' => 'Are you sure you want to delete this Equipment?',
                                            ]);
                                        },
                                        'view' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon icon-eye-open my_font_icon"></span>', $url, [
                                                        'title' => Yii::t('app', 'view'), 'data-pjax' => '0',
                                            ]);
                                        },
                                        'update' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon icon-pencil my_font_icon"></span>', $url, [
                                                        'title' => Yii::t('app', 'update'), 'data-pjax' => '0',
                                            ]);
                                        },
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if ($action === 'delete') {
                                            $url = Yii::$app->urlManager->createUrl(['equipment/delete', 'id' => $model->pkEquipmentID]);
                                            //$url ='../../../view?slug='.$model->slug;
                                            return $url;
                                        }
                                        if ($action === 'view') {
                                            $url = Yii::$app->urlManager->createUrl(['equipment/view', 'id' => $model->pkEquipmentID]);
                                            return $url;
                                        }
                                        if ($action === 'update') {
                                            $url = Yii::$app->urlManager->createUrl(['equipment/update', 'id' => $model->pkEquipmentID]);

                                            return $url;
                                        }
                                    }
                                ],
                            ],
                        ]);
                        ?>
                    </div>
                    <?= Html::endForm() ?>
                        <?php \yii\widgets\Pjax::end(); ?>
                        <?php echo common\components\PaginationField::widget(); ?>

            </div>

        </div>

    </div>
</div>