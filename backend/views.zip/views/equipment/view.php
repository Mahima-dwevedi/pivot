<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use backend\models\Equipment;
/* @var $this yii\web\View */
/* @var $model backend\models\Equipment */

$this->title = $model->pkEquipmentID;
$this->params['breadcrumbs'][] = ['label' => 'Equipments', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div id="margin_mobile" class="page-header">
    <div class="pull-left">
        <h1><?= Html::encode($this->title) ?></h1>
    </div>
</div>

<div class="breadcrumbs">
    <ul>
        <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
        <li><?php // echo Html::a('Manage Farms', ['/farm']); ?><i class="icon-angle-right"></i></li>
        <li><span class="readcrum_without_link">View Farm </span></li>
    </ul>
    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>


<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3>View Plan</h3>
               <!-- <a class="btn pull-right" data-toggle="modal" href="<?php  // echo Yii::$app->urlManager->createUrl('/farm'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
        !-->    </div>
            <div class="box-content nopadding">
                <?= 
                DetailView::widget([
                    'model' => $model,
                   
                    'attributes' => [
                       [
                            'label' => 'Farm Name',
                            'format' => 'raw',
                            'value' => $model->EquipmentName,
                        ],
                        [
                            'label' => 'Name',
                            'format' => 'raw',
                            'value' => $model->EqpLocationType,
                        ],
                        [
                            'label' => 'Username',
                            'format' => 'raw',
                            'value' => $model->Longitude,
                        ],
                        [
                            'label' => 'Email Address',
                            'format' => 'raw',
                            'value' => $model->Latitude,
                        ],
                        [
                            'label' => 'Contact Detail',
                            'format' => 'raw',
                            'value' => $model->EqpWateringChart,
                        ],
                        [
                            'label' => 'Address1',
                            'format' => 'raw',
                            'value' => $model->EqpStartup,
                        ],
                        
                        [ 'attribute'=>'farmLicenseStartDate',
                            'format' => 'raw',
                             'value' => date("d-m-Y",  strtotime($model->EqpCreatedDate)),
                        ],
                     
                        
                      ],
                ])
                ?>

            </div>

        </div>
    </div>
</div>

