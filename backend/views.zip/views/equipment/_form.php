<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;
use backend\models\Irrigationsystem;
use yii\helpers\ArrayHelper;
use backend\models\Field;
use backend\models\Equipment;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\models\Farm */
/* @var $form yii\widgets\ActiveForm */
$baseUrl = Url::base();
?>
<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-table"></i><?= Html::encode($this->title) ?></h3>
                <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/equipment'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
            </div>
            <div class="box-content nopadding">
                <?php yii\widgets\Pjax::begin(['id' => 'farm-gird']) ?>
                <?php
                $form = ActiveForm::begin([
                            'id' => 'farm-form',
                            'enableAjaxValidation' => false,
                            'options' => [
                                'class' => 'form-horizontal form-bordered form-validate',
                                'enctype' => 'multipart/form-data',
                            ],
                ]);
                ?>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'fkFieldID', ['label' => 'Field Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">   
                            <?php
                            $modelfield = new field();
                            $modelfld = $modelfield->getAllfield(); //echo '<pre>';print_r($modelfld); die;
                            echo $form->field($model, 'fkFieldID')->dropDownList($modelfld, ['prompt' => 'Select Field Name'])->label(false);
                            ?>

                        </div>
                    </div><div class="cb"></div>  
                </div>

                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'EquipmentType', ['label' => 'Equipment Type<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?php echo $form->field($model, 'EquipmentType')->dropDownList([ '0' => 'Pivot', '1' => 'Water Pump', '2' => '28  Pump'], ['prompt' => 'Select Equipment Type', 'onchange' => 'equipmenttype(this.value);'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'EquipmentName', ['label' => 'Equipment Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'EquipmentName', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Equipment Name'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'EqpManufacturer', ['label' => 'Equipment Manufacturer', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'EqpManufacturer', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Equipment Manufacturer'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'EqpModel', ['label' => 'Equipment Model', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'EqpModel', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Equipment Model'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>


                <div class="pivottype"  id ="pivotid" style="<?= $model->EquipmentType == '0' ? 'display:block' : 'display:none' ?>">
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'EqpLength', ['label' => 'Length of Pivot(in ft)<span class="required">*</span>', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'EqpLength', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Length of Pivot'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>

                    <?php $model->FullCircle = 1; ?>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'FullCircle', ['label' => 'Full Circle(in Degrees)', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'FullCircle')->checkbox()->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>

                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'EqpCycleRangeStart', ['label' => 'Pivot Cycle Range Start(in Degrees)', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'EqpCycleRangeStart', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Cycle Range Start', 'readonly' => true])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'EqpCycleRangeEnd', ['label' => 'Pivot Cycle Range End(in Degrees)', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'EqpCycleRangeEnd', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Cycle Range End', 'readonly' => true])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'gunThrow', ['label' => 'Gun Throw(in ft)', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'gunThrow', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Gun Throw'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'hoursperRevolution', ['label' => 'Hours Per Revolution at 100%', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'hoursperRevolution', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Hours Per Revolution'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'ApplicationRate', ['label' => 'Minimum Application Rate', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'ApplicationRate', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Application Rate'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                </div>
                <div class="equipmenttype"  id ="waterpumpid" style="<?= $model->EquipmentType == '1' ? 'display:block' : 'display:none' ?>">

                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'electricVsdiesel', ['label' => 'Power Source', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?php echo $form->field($model, 'electricVsdiesel')->radioList(array('0' => 'Electric', 1 => 'Diesel'))->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>

                </div>
                <div class="equipmenttype"  id ="pump28" style="<?= $model->EquipmentType == '2' ? 'display:none' : 'display:none' ?>">
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'gallonsperMinute', ['label' => 'Gallons Per Minute', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'gallonsperMinute', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Gallons Per Minute'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>

                </div>

                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'Latitude', ['label' => 'Latitude<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'Latitude', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Latitude'])->label(false); ?>
                            <span>example: 28.6139</span>
                        </div>

                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'Longitude', ['label' => 'Longitude<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'Longitude', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Longitude'])->label(false); ?>
                            <span>example: 77.2090</span>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>

                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'deviceOffset', ['label' => 'Device Offset(in Degrees)', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'deviceOffset', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Device Offset'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>


                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'EqpAcresWatered', ['label' => 'Acres Watered<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'EqpAcresWatered', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Acres Watered'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'EqpWellCapacity', ['label' => 'Well Capacity<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'EqpWellCapacity', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Well Capacity'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <?php if ($model->isNewRecord) { ?>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'EqpWateringChart', ['label' => 'Watering Chart', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'EqpWateringChart', ['errorOptions' => ['class' => 'error']])->fileInput()->label(false); ?>
                                <span>Allowed File extensions are : ['png', 'jpg', 'gif', 'jpeg', 'pdf']</span>

                                <?php //= $form->field($model, 'EqpWateringChart', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Watering Chart'])->label(false);    ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                <?php } else { ?>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'EqpWateringChart', ['label' => 'Watering Chart', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'EqpWateringChart', ['errorOptions' => ['class' => 'error']])->fileInput()->label(false); ?>
                                <?= $form->field($model, 'OldEqpWateringChart', ['errorOptions' => ['class' => 'error']])->hiddenInput(['value' => $model->EqpWateringChart])->label(false); ?>
                                <?= $form->field($model, 'pkEquipmentID')->hiddenInput(['value' => $model->pkEquipmentID])->label(false) ?>
                                <?php if($model->EqpWateringChart){ ?>
                                    <a data-pjax='0' target="_blank" href="<?php echo $baseUrl;?>/uploaded_files/water_chart/<?php echo $model->EqpWateringChart;?>">Watering Chart</a>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                <?php } ?>


                <?php if ($model->isNewRecord) { ?>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'pivotInstructions', ['label' => 'Pivot Instructions', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'pivotInstructions', ['errorOptions' => ['class' => 'error']])->fileInput()->label(false); ?>
                                <span>Allowed File extensions are : ['jpg','pdf']</span>

                                <?php //= $form->field($model, 'EqpWateringChart', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Watering Chart'])->label(false);    ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                <?php } else { ?>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'pivotInstructions', ['label' => 'Pivot Instructions', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'pivotInstructions', ['errorOptions' => ['class' => 'error']])->fileInput()->label(false); ?>
                                <?= $form->field($model, 'OldpivotInstructions', ['errorOptions' => ['class' => 'error']])->hiddenInput(['value' => $model->pivotInstructions])->label(false); ?>
                                <?= $form->field($model, 'pkEquipmentID')->hiddenInput(['value' => $model->pkEquipmentID])->label(false) ?>
                                <?php if($model->pivotInstructions){ ?>
                                    <a data-pjax='0' target="_blank" href="<?php echo $baseUrl;?>/uploaded_files/pivot_instruction/<?php echo $model->pivotInstructions;?>">Pivot Instructions</a>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                <?php } ?>


                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'EqpAmpsperHour', ['label' => 'Pivot Amps Used per Hour', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'EqpAmpsperHour', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Pivot Amps Used per Hour'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'EqpStartup', ['label' => 'Start Up Procedure', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'EqpStartup', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Start up Procedure'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>

                <div class="note"><strong>Note :</strong> <span class="required">*</span> Indicates mandatory fields.</div>

                <div class="form-actions">  
                    <?= Html::submitButton($model->isNewRecord ? 'Create Equipment' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    <?php echo Html::a('Cancel', array('/equipment'), array('class' => 'btn')); ?>  
                </div>




                <?php ActiveForm::end(); ?>
                <?php yii\widgets\Pjax::end() ?>
            </div>
        </div>
    </div>
</div>
<script>

    $(document).ready(function() {

        $("#equipment-fullcircle").change(function() {
            if ($(this).is(':unchecked')) {
                $('#equipment-eqpcyclerangestart ,#equipment-eqpcyclerangeend').attr('readonly', false);
                $('#equipment-eqpcyclerangestart ,#equipment-eqpcyclerangeend').val('');
//                $("#equipment-eqpcyclerangestart").val('');
//                $("#equipment-eqpcyclerangeend").val('');

            } else {
                $('#equipment-eqpcyclerangestart ,#equipment-eqpcyclerangeend').attr('readonly', true);
                $("#equipment-eqpcyclerangestart").val('0');
                $("#equipment-eqpcyclerangeend").val('360');
            }
        });

    });

    function equipmenttype(id)
    {
        var pivot = parseInt($.trim(id));

        if (pivot === 0)
        {
            $('#waterpumpid').css('display', 'none');
            $('#pivotid').css('display', 'block');
            $('#pump28').css('display', 'block');
        }
        else if (pivot === 1)
        {
            $('#waterpumpid').css('display', 'block')
            $('#pivotid').css('display', 'none');
            $('#pump28').css('display', 'block');
        }
        else if (pivot === 2)
        {
            $('#waterpumpid').css('display', 'none')
            $('#pivotid').css('display', 'none');
            $('#pump28').css('display', 'none');
        }
    }



    $(document).ready(function() {

        $('#equipment-fkfieldid').on('change', function() {

            var drop = $('#equipment-fkfieldid').val();
            $("#irrigationsystem-irrigationid").empty("<option value=''></option>");
            if (drop != "") {
                
                jQuery.ajax({
                    type: "GET",
                    url: "getirrigation",
                    data: "id=" + drop,
                    dataType: "html",
                    success: function(data)
                    {
                        var json = JSON.parse(data);
                        //console.log(json);
                        $("#irrigationsystem-irrigationid").empty("<option value=''></option>");

                        $.each(json.irrigationData, function(index, value) {

                            //console.log(value);
                            $("#irrigationsystem-irrigationid").append("<option value='" + index + "'>" + value + "</option>");

                        });
                    }


                });
            }


        });

    });

//
//
//    $(document).ready(function() {
//
//        $('#irrigationsystem-irrigationid').on('change', function() {
//
//            var drop = $('#equipment-fkfieldid').val();
//
//            jQuery.ajax({
//                type: "GET",
//                url: "getirrigation",
//                data: "id=" + drop,
//                dataType: "html",
//                success: function(data)
//                {
//                    var json = JSON.parse(data);
//                    //console.log(json);
//                    $("#irrigationsystem-irrigationid").empty("<option value=''></option>");
//
//                    $.each(json.irrigationData, function(index, value) {
//
//                        console.log(value);
//                        $("#irrigationsystem-irrigationid").append("<option value='" + index + "'>" + value + "</option>");
//
//                    });
//                }
//
//
//            });
//        });
//
//
//
//
//    });

</script>