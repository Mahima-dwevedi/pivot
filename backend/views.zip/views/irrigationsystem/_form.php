<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\Irrigationsystem */
/* @var $form yii\widgets\ActiveForm */
//die('dsf');
?>

<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-table"></i><?= Html::encode($this->title) ?></h3>
                <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/irrigationsystem'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
            </div>
            <div class="box-content nopadding">
                <?php yii\widgets\Pjax::begin(['id' => 'irrrigation-gird']) ?>
                <?php $form = ActiveForm::begin([
                            'id' => 'farm-form',
                            'enableAjaxValidation' => false,
                            'options' => [
                                'class' => 'form-horizontal form-bordered form-validate',
                                'enctype' => 'multipart/form-data',
                            ],
                ]); ?>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'irrigationName', ['label' => 'Irrigation Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?php echo $form->field($model, 'irrigationName')->textInput()->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>

                <div class="fullwidth">
                    <div class="control-group">
                        <?php //print_r(@$field);?>
                        
                        <?= Html::activeLabel($model, 'fkFieldID', ['label' => 'Field Name', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?php echo $form->field($model, 'fkFieldID')->dropDownList($field,['prompt'=>'Select Field'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>

            
                <div class="note"><strong>Note :</strong> <span class="required">*</span> Indicates mandatory fields.</div>

                <div class="form-actions">  
                    <?= Html::submitButton($model->isNewRecord ? 'Create Irrigation' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    <?php echo Html::a('Cancel', array('/irrigationsystem'), array('class' => 'btn')); ?>  
                </div>

             

                <?php ActiveForm::end(); ?>

            </div>
        </div>

    </div>
</div>

