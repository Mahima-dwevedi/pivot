<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\IrrigationSystemSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Manage Irrigation System';
$this->params['breadcrumbs'][] = $this->title;

require(__DIR__ . '/irrigation_multipleActionJs.php');
?>
<div class="pull-right margin_top20 mobile_margin">
    <?= Html::a('Add Irrigation System', ['create'], ['class' => 'btn btn-success']) ?>
</div>
<div class="irrigationsystem-index">

    <div class="page-header">
        <div class="pull-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>          
    </div>
    <div class="breadcrumbs">
        <ul>
            <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
            <li><?php echo Html::a('Manage Fields', ['/field/index']); ?><i class="icon-angle-right"></i></li>
            <li><span class="readcrum_without_link"><?=$this->title; ?></span></li>
        </ul>
        <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
    </div>

    <div class="breadcrumbs" id="breadcrumbs-msg">

        <?php
        if ((Yii::$app->session->hasFlash('create')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active'))) {
            ?>
            <ul>
                <?php
                if (Yii::$app->session->getFlash('create')) {
                    echo '<li><span class="readcrum_without_link_success">' . ADD_IRRIGATION_SUCCESS . '</li>';
                } else if (Yii::$app->session->getFlash('update')) {
                    echo '<li><span class="readcrum_without_link_success">' . IRRIGATION_UPDATE . '</li>';
                } else if (Yii::$app->session->getFlash('delete')) {
                    echo '<li><span class="readcrum_without_link_success">' . IRRIGATION_DELETE . '</li>';
                } else if (Yii::$app->session->getFlash('error')) {
                    echo '<li><span class="readcrum_without_link_error">' . ASSIGN_FIELDTECH_ERROR . '</li>';
                }
                ?>
            </ul>
        <?php }
        ?>
    </div>
    <div id="message"></div>

    <div class="search-form">
        <?php echo $this->render('_search', ['model' => $searchModel]); ?>
    </div>

    <div class="box box-color box-bordered">
        <div class="box-title">
            <h3><i class="icon-reorder"></i> Manage Irrigation System</h3>
            <!--<a class="btn pull-right" data-toggle="modal" href="#" id = "viewAll">View All</a>-->
        </div>
        <div class="clear"></div>

        <div class="box-content nopadding">
            <?php \yii\widgets\Pjax::begin(['id' => 'irrigation-grid']); ?>  
            <?php echo Html::beginForm($action = '', $method = 'POST', ['name' => 'irrigation-grid-list-form', 'id' => 'irrigation-grid-list-form']) ?>


			<div class="table-responsive">
            <?=
            GridView::widget([
                'dataProvider' => $dataProvider,
                // 'filterModel' => $searchModel,
                'columns' => [

                    [
                        'name' => 'id',
                        'class' => 'yii\grid\CheckboxColumn',
                        'headerOptions' => ['width' => '3%'],
                    ],
//                    'irrigationID',
                    'irrigationName',
                    [
                        'attribute' => 'field.fieldName',
                        'label'=>'Assigned Field Name',
                        'value' => function($data) {

                            return (@$data->field->fieldName) ? $data->field->fieldName : 'Not Assigned';
                        }
                    ],
                    [
                        'attribute' => 'irrigationAddedDate',
                        'value' => function($data) {
                            return Date('m-d-Y', strtotime($data->irrigationAddedDate));
                        }
                    ],
//                    'irrigationUpdatedDate',
                    // 'fkFarmID',
                    // 'fkParentID',
                    ['class' => 'yii\grid\ActionColumn', 'header' => 'Action', 'template' => '{update} &nbsp;&nbsp;&nbsp;{delete}'],
                ],
            ]);
            ?>
			</div>
            <div class="control-group">
                <div class="controls faqstatusDropdown">
                    <?= Html:: dropDownList('irrigationID', '', ['delete' => 'Delete'], ['prompt' => '--Choose Action--', 'onchange' => 'IrrigationMultipleAction(this.value)', 'id' => 'irrigation']) ?>
                </div>
            </div>

            <?= Html::endForm() ?>         
            <?php \yii\widgets\Pjax::end(); ?>
        </div>

    </div>

</div>
