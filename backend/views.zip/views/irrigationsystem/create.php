<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Irrigationsystem */

$this->title = 'Add Irrigation System';
$this->params['breadcrumbs'][] = ['label' => 'Irrigationsystems', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
//print_r($field);die;
?>
<div id="margin_mobile" class="page-header create_mobile_header">
    <div class="pull-left">
        <h1> <?=$this->title ?></h1>
    </div>
</div>
<div class="breadcrumbs">
    <ul>
        <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
        <li><?php echo Html::a('Manage Irrigation System',['/irrigationsystem/']); ?><i class="icon-angle-right"></i></li>
        <li><span class="readcrum_without_link">Add Irrigation System</span></li>
    </ul>
    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>
<div class="irrigationsystem-create">


    <?= $this->render('_form', [
        'model' => $model,
        'field'=>$field,
        //'farm'=>$farm
    ]) ?>

</div>
