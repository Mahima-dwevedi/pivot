<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\widgets\TypeaheadBasic;
/* @var $this yii\web\View */
/* @var $model app\models\IrrigationSystemSearch */
/* @var $form yii\widgets\ActiveForm */
?>


<div class="wide form">
    <div class="box box-color box-bordered">
        <div class="box-title">
            <h3><i class="icon-reorder"></i>Search</h3>
            <div class="actions">
                <a href="#" class="btn btn-mini content-slideUp"><i class="icon-angle-down"></i></a>
            </div>
        </div>

        <div class="box-content">

            <?php
            $form = ActiveForm::begin([
                        'action' => ['index'],
                        'method' => 'get',
            ]);
            ?>

            <div class="span4">
                <div class="control-group">
                    <div class="controls">
                        <?php
//                        if($model->searchIrrigationList){
//                             echo $form->field($model, 'irrigationName')->widget(TypeaheadBasic::classname(), [
//                            'data' => $model->searchIrrigationList,
//                            'options' => ['placeholder' => 'Type Irrigation Name'],
//                            'pluginOptions' => ['highlight' => true],
//                        ]);
//                        }else{
                            echo $form->field($model, 'irrigationName')->textInput(['placeholder'=>'Type Irrigation Name']);
//                        }
                       
                        ?>
                        <?php // echo $form->field($model, 'irrigationName') ?>
                    </div>
                </div>
            </div>

            <div class="span4">
                <div class="control-group">
                    <div class="controls">
                        <?php
//                        if($model->searchFieldList){
//                            echo $form->field($model, 'fkFieldID')->widget(TypeaheadBasic::classname(), [
//                            'data' => $model->searchFieldList,
//                            'options' => ['placeholder' => 'Type Field Name'],
//                            'pluginOptions' => ['highlight' => true],
//                        ]);
//                        }else{
                            echo $form->field($model, 'fkFieldID')->textInput(['placeholder' => 'Type Field Name']);
//                        }
                        
                        ?>
                        <?php //echo $form->field($model, 'fkFieldID') ?>
                    </div>
                </div>
            </div>




            <div class="row-fluid span12">
                <div class="search">
                    <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
                    <?= Html::a('Reset', ['/irrigationsystem'], ['class' => 'btn btn-default']) ?>
                </div>
            </div>

            <?php ActiveForm::end(); ?>

        </div>
    </div>

</div>

