<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\helpers\Url;

$baseUrl = Yii::$app->getUrlManager()->getBaseUrl();
$imagePath = Yii::$app->request->BaseUrl;
$varID = isset($_GET['ID']) ? ($_GET['ID']) : 0;
$this->title = 'Field List View';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-index"><?php echo "<!-- ID=" . $varID . "-->\n"; ?>

    <div class="page-header">
        <div class="pull-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>          
    </div>
    <!--    <di v class="breadcrumbs">
            <ul>
                <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
                <li><span class="readcrum_without_link">list of all fields</span></li>
            </ul>
            <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>-->
</div>
<section class="col-md-12 list_view_main_wrapper">
    <section class="col-md-3 view_left_panel"><!--Left Panel-->
        <a href="<?php echo Url::base();?>/list-view"><button type="button" class="col-md-12 view_fields <?php echo  ($varID == 0 ) ? 'list_active' : '' ?>">All</button></a>
        <?php
        foreach ($model as $fieldvalue)
        {
            ?>
            <a href="?ID=<?php echo $fieldvalue['fieldID']; ?>">
                <button type="button" class="col-md-12 view_fields <?= ($fieldvalue['fieldID'] == $varID ) ? 'list_active' : '' ?>">
            <?php echo $fieldvalue['fieldName'] ?>
                </button></a>
        <?php }
        ?>

    </section>
    <section class="col-lg-9 view_right_panel">   
        <?php
//        echo "<pre>";
//                print_r($allEquipment);
        foreach ($allEquipment as $eqpvalue)
        {
            ?>
            <?php
            if (count($eqpvalue) > 0)
            {
                ?>

                <section class="col-md-4">
                    <section class="pivot_detail pivot_detail_with_padding box">
                        <h5>Field Name: </h5><span class="pivot_name"><?= $eqpvalue['fieldName'] == '' ? 'N/A' : $eqpvalue['fieldName'] ?></span>
                        <h5>Equipment Name: </h5><span class="pivot_name"><?= $eqpvalue['EquipmentName'] == '' ? 'N/A' : $eqpvalue['EquipmentName'] ?></span>
                        <h5>Position: </h5><span class="pivot_speed"><?= $eqpvalue['heading'] ?>&deg;</span>
                        <h5>Pressure: </h5><span class="pivot_pressure">
                            <?php
                            if ($eqpvalue['pressure'] == "1" && $eqpvalue['movementColor'] != "Gray")
                            {
                                $pressureImagePath = "/img/greenCircle.png";
								
                            } elseif ($eqpvalue['pressure'] == "0" && $eqpvalue['movementColor'] != "Gray"){
								
                                $pressureImagePath = "/img/redCircle.png";
								
							} else
                            {
                                $pressureImagePath = "/img/grayCircle.png";
                            }

                            ?>
                            <?= Html::img($imagePath . $pressureImagePath, ['width' => 15, "height" => 15]) ?>

                        </span>
						<?php
                            $movementImagePath = "/img/" . strtolower($eqpvalue['movementColor']) . "Circle.png";
                        ?>
                        <h5>Movement: </h5><span class="pivot_dir"><?= Html::img($imagePath . $movementImagePath, ['width' => 15, "height" => 15]) ?></span>
						
                        <h5><?= $eqpvalue['motionReason'][0] ?></h5><span class="pivot_dir"><?= $eqpvalue['motionReason'][1] ?></span>
                        <div class="pivot-btn">
                            <?php
                            if ($eqpvalue['fkDeviceID'] != '')
                            {
                                if ($eqpvalue['EqpStatus'] == '1')
                                {
                                    echo Html::a('Stop', 'javascript:stopEqup(' . $eqpvalue["pkEquipmentID"] . ')', ['class' => 'pivot_stop_btn', "data-confirm" => "Are you sure you want to do STOP this equipment?"]);
                                }
                                else
                                {
                                    echo Html::a('Start Pivot', ['equipmentmeta/create?id=' . $eqpvalue['pkEquipmentID']."&type=".Yii::$app->controller->id], ['class' => 'pivot_start_btn', 'data-confirm' => 'Are you sure you want to do START this equipment?']);
                                }
                            }
                            echo Html::a('Summary', ['pivot-summary/index?id=' . $eqpvalue['pkEquipmentID']], ['class' => 'pivot_start_btn']);
                            ?>
                        </div>
                        <?php
                        $pressureImagePath = "";
                        if ($eqpvalue['fkDeviceID'] != '')
                        {
                            if (($eqpvalue['pressure'] == "1" && $eqpvalue['movementColor'] == "Green"))
                            {
                                $pressureImagePath = "/img/greenCircle.png";
								
                            }elseif (($eqpvalue['pressure'] == "0" && $eqpvalue['movementColor'] == "Red") || $eqpvalue['movementColor'] == "Gray")
                            {
                                $pressureImagePath = "/img/grayCircle.png";   
								
                            } elseif ($eqpvalue['movementColor'] == "Yellow"){
								
								$pressureImagePath = "/img/yellowCircle.png"; 
								
							} else {
								
								$pressureImagePath = "/img/redCircle.png"; 
							}

                            if ($pressureImagePath != '')
                            {
                                ?>
                                <section class="pivot_angle"><?= Html::img($imagePath . $pressureImagePath, ['width' => 30, "height" => 30]) ?></section>
								<?php
							}
						}
						?>

                    </section>
                </section>


        <?php
    }
}
?>
    </section>
</section>

<script>
    function stopEqup(id) {
        $.ajax({
            url: "<?= $baseUrl ?>/list-view/stop-equip",
            method: "GET",
            data: {id: id},
            success: function() {

            }
        });
    }

    //Apply same height to the boxes on a page
    $(window).load(function() {
        var maxHeight = 0;
        $(".box").each(function() {
            if ($(this).height() > maxHeight) {
                maxHeight = $(this).height();
            }
        });
        $(".box").height(maxHeight);
    });
</script>