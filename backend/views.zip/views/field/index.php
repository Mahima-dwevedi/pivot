<?php

use yii\helpers\Html;
use yii\grid\GridView;

require(__DIR__ . '/field_multipleActionJs.php');
/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchBank */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Manage Fields';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="pull-right margin_top20 mobile_margin">
    
    <?php // Html::a('Manage Irrigation System', ['/irrigationsystem'], ['class' => 'btn btn-success field_button']) ?>
    <?= Html::a('Create Field', ['create'], ['class' => 'btn btn-success field_button']) ?>
    
</div>

<div class="user-index">

    <div class="page-header">
        <div class="pull-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>          
    </div>
    <div class="breadcrumbs">
        <ul>
            <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
            <li><span class="readcrum_without_link">Manage fields</span></li>
        </ul>
        <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
    </div>
    <div id="message"></div>
    <div class="row-fluid">
        <div class="breadcrumbs" id="breadcrumbs-msg">

            <?php if ((Yii::$app->session->hasFlash('create')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('assign')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active')))
            { ?>
                <ul>
                    <?php
                    if (Yii::$app->session->getFlash('create'))
                    {
                        echo '<li><span class="readcrum_without_link_success">' . ADD_FIELD_SUCCESS . '</li>';
                    }
                    else if (Yii::$app->session->getFlash('update'))
                    {
                        echo '<li><span class="readcrum_without_link_success">' . EDIT_FIELD_SUCCESS . '</li>';
                    }
                    else if (Yii::$app->session->getFlash('delete'))
                    {
                        echo '<li><span class="readcrum_without_link_success">' . DELETE_FIELD_SUCCESS . '</li>';
                    }
                    else if (Yii::$app->session->getFlash('error'))
                    {
                        echo '<li><span class="readcrum_without_link_success">' . ERROR_FIELD_SUCCESS . '</li>';
                    }
                    else if (Yii::$app->session->getFlash('assign'))
                    {
                        echo '<li><span class="readcrum_without_link_success">' . ASSIGN_FIELD_TECHNICIAN_SUCCESS . '</li>';
                    }
                    ?>						
                </ul>
<?php }
?>
        </div>
        <div class="search-form">
<?php echo $this->render('_searchfield', ['model' => $searchModel]); ?>
        </div><!-- search-form -->
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-reorder"></i>List of all fields</h3>
                <!--<a class="btn pull-right" data-toggle="modal" href="#" id = "viewAll">View All</a>-->
            </div>
            <div class="clear"></div>

            <div class="box-content nopadding">

                <!--<form action="" name='farm-grid-list-form' id='farm-grid-list-form'>-->
                <?php \yii\widgets\Pjax::begin(['id' => 'farm-grid']); ?>  
                <?php echo Html::beginForm($action = '', $method = 'POST', ['name' => 'farm-grid-list-form', 'id' => 'farm-grid-list-form']) ?>
				<div class="table-responsive">
                <?=
                GridView::widget([
                    'dataProvider' => $dataProvider,
                    'id' => 'farm-grid',
                    'columns' => [
                        [
                            'name' => 'id',
                            'class' => 'yii\grid\CheckboxColumn',
                            'headerOptions' => ['width' => '3%'],
                        ],
                        //  ['class' => 'yii\grid\SerialColumn'],
                        [
                            'attribute' => 'fieldInputID',
                            'label' => 'Field ID',
                            'format' => 'raw',
                            'value' => function ($data)
                            {
                                return $data->fieldInputID; // $data['name'] for array data, e.g. using SqlDataProvider.
                            },
                        ],
                        [
                            'attribute' => 'fieldName',
                            'label' => 'Field Name',
                            'value' => function ($data)
                            {
                                return $data->fieldName; // $data['name'] for array data, e.g. using SqlDataProvider.
                            },
                        ],
                        [
                            'attribute' => 'fieldAddDate',
                            'label' => 'Date Created',
                            'value' => function ($data)
                            {
                                return date("m-d-Y", strtotime($data->fieldAddDate)); // $data['name'] for array data, e.g. using SqlDataProvider.
                            },
                        ],
                        [
                            'attribute' => 'FeildtechName',
                            'label' => 'Field Technician Name',
                            'value' => function ($data)
                            {

                                if ($data->getField($data->fieldID) == '')
                                {
                                    return "not assigned";
                                }
                                else
                                {
                                    return $data->getFieldtech($data->fieldID);
                                }
                            },
                        ],
                        [
                            'header' => 'Action',
                            'class' => 'yii\grid\ActionColumn',
                            'template' => '{Equipments} {delete} {Edit}{view}',
                            'buttons' => [
                                'Equipments' => function ($url, $model)
                                {
                                    return Html::a('Equipments', $url, [
                                                'title' => Yii::t('app', 'Equipments'), 'data-pjax' => '0',
                                            ]);
                                },
                               // 'IrrigationSystem' => function ($url, $model)
                               // {
                                  //  return Html::a('Irrigation System   ', $url, [
                                        //        'title' => Yii::t('app', 'IrrigationSystem'), 'data-pjax' => '0',
                                        //    ]);
                               // },
//                                     'delete'=>function ($url,  $model){
//                                        return Html::a('<span class="glyphicon icon-trash my_font_icon"></span>', $url, [
//                                                    'title' => Yii::t('app', 'delete'), 'data-pjax' => '0',
//                                        ]);
//                                     },
                                'Edit' => function ($url, $model)
                                {
                                    return Html::a('<span class="glyphicon icon-pencil my_font_icon"></span>', $url, [
                                                'title' => Yii::t('app', 'update'), 'data-pjax' => '0',
                                            ]);
                                },
                                'view' => function ($url, $model)
                                {
                                    return Html::a('<span class="glyphicon icon-eye-open my_font_icon"></span>', $url, [
                                                'title' => Yii::t('app', 'view'), 'data-pjax' => '0',
                                            ]);
                                },
                            ],
                            'urlCreator' => function ($action, $model, $key, $index)
                            {

                                if ($action === 'Equipments')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['field/view', 'id' => $model->fieldID]);

                                    return $url;
                                }
                               /* if ($action === 'IrrigationSystem')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['field/viewirrigation', 'id' => $model->fieldID]);

                                    return $url;
                                }*/
                                if ($action === 'delete')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['field/delete', 'id' => $model->fieldID]);

                                    return $url;
                                }
                                if ($action === 'Edit')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['field/edit', 'id' => $model->fieldID]);

                                    return $url;
                                }
                                if ($action === 'view')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['field/viewfield', 'id' => $model->fieldID]);
                                    return $url;
                                }
                            }
                    ],
                        ],
                ]);
                ?>
                <div class="control-group">
                    <div class="controls faqstatusDropdown">
<?= Html:: dropDownList('fieldID ', '', ['delete' => 'Delete',], ['prompt' => '--Choose Action--', 'onchange' => 'fieldMultipleAction(this.value)', 'id' => 'field']) ?>
                    </div>
                </div>
                <?= Html::endForm() ?>         
<?php \yii\widgets\Pjax::end(); ?>
<?php echo common\components\PaginationField::widget(); ?>
                </div>
                 
            </div>

        </div>
    </div>
