<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\user */

$this->title = 'Assign Device';
$this->params['breadcrumbs'][] = ['label' => 'Manage Relationship', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $modelEquipment->pkEquipmentID, 'url' => ['view',  'id' => $modelEquipment->pkEquipmentID]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div id="margin_mobile" class="page-header">
    <div class="pull-left">
        <h1> <?=$this->title ?></h1>
    </div>
</div>
<div class="breadcrumbs">
    <ul>
        <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
        <li><?php echo Html::a('Manage devices',['/field/index_relationship']); ?><i class="icon-angle-right"></i></li>
        <li><span class="readcrum_without_link"> <?=$this->title ?></span></li>
    </ul>
    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>

<?=
$this->render('_formupdaterelation', [
    'model' => $model,
   // 'modelIrrigation' => $modelIrrigation,
    'modelEquipment' => $modelEquipment,
    'modelDevice' => $modelDevice,
])
?>
