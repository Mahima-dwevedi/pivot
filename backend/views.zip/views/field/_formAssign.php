<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
//use yii\jui\DatePicker;
use yii\helpers\ArrayHelper;
use backend\models\Irrigationsystem;
use backend\models\Field;
use backend\models\Equipment;
use backend\models\Device;
use yii\jui\DatePicker;

/* @var $this yii\web\View */
/* @var $model app\models\Farm */
/* @var $form yii\widgets\ActiveForm */
?>
<?php // print_r($listData); die;             ?>
<div class="row-fluid">
    <div class="breadcrumbs" id="breadcrumbs-msg">

        <?php
        if ((Yii::$app->session->hasFlash('errorupdate')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active'))) {
            ?>
            <ul>
            <?php
            if (Yii::$app->session->getFlash('create')) {
                echo '<li><span class="readcrum_without_link_success">' . ADD_DEVICE_SUCCESS . '</li>';
            } else if (Yii::$app->session->getFlash('update')) {
                echo '<li><span class="readcrum_without_link_success">' . ASSIGN_DEVICE_SUCCESS . '</li>';
            } else if (Yii::$app->session->getFlash('delete')) {
                echo '<li><span class="readcrum_without_link_success">' . DELETE_FIELD_SUCCESS . '</li>';
            } else if (Yii::$app->session->getFlash('error')) {
                echo '<li><span class="readcrum_without_link_success">' . ERROR_FIELD_SUCCESS . '</li>';
            } else if (Yii::$app->session->getFlash('errorupdate')) {
                echo '<li><span class="readcrum_without_link_success">' . FIELD_ASSIGN_ERROR . '</li>';
            }
            ?>						
            </ul>
            <?php }
            ?>
    </div>

    <div class="box box-color box-bordered">
        <div class="box-title">
            <h3><i class="icon-table"></i><?= Html::encode($this->title) ?></h3>
            <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/field/index_relationship'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
        </div>
        <div class="box-content nopadding">
        <?php yii\widgets\Pjax::begin(['id' => 'farm-gird']) ?>
        <?php
        $form = ActiveForm::begin([
                    'id' => 'farm-form',
                    'enableAjaxValidation' => false,
                    'options' => [
                        'class' => 'form-horizontal form-bordered form-validate',
                    ],
        ]);
        ?>
            <div class="control-group">
            <?= Html::activeLabel($model, 'fieldID', ['label' => 'Field Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                <div class="controls">   

            <?php
            $modelfield = new field();
            $modelfld = $modelfield->getAllfield(); 
            echo $form->field($model, 'fieldID')->dropDownList($modelfld, ['prompt' => 'Select Field'])->label(false);
            ?>


                </div>
            </div>

            <div class="control-group">
                <?= Html::activeLabel($modelEquipment, 'pkEquipmentID', ['label' => 'Equipment Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                <div class="controls">   
                    <?php
                    $id = Yii::$app->user->id;

                  
                    $listData = ArrayHelper::map( $Equipmentlist, 'pkEquipmentID', 'EquipmentName');
                    echo $form->field($modelEquipment, 'pkEquipmentID')->dropDownList($listData, ['prompt' => 'Select Equipment'])->label(false);
                    ?>	     
                </div>
            </div>
            <div class="control-group">
                    <?= Html::activeLabel($modelDevice, 'pkDeviceID', ['label' => 'Device Unit Number<span class="required">*</span>', 'class' => 'control-label']) ?>
                <div class="controls">   
                    <?php 
                    $id = Yii::$app->user->id;
                    $modeldvc = $model->getdevice($id);
                    $listData = ArrayHelper::map($modeldvc, 'pkDeviceID', 'DeviceUnitNo'); // echo '<pre>'; print_r($listData); die;
                    echo $form->field($modelDevice, 'pkDeviceID')->dropDownList($listData, ['prompt' => 'Select Device'])->label(false);
                    ?>
                </div>
            </div>
            <div class="note span11"><strong>Note :</strong> <span class="required">*</span> Indicates mandatory fields.</div>
            <div class="form-actions span11">
                    <?= Html::submitInput($model->isNewRecord ? 'Assign' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    <?php echo Html::a('Cancel', array('/field/index_relationship'), array('class' => 'btn')); ?>
            </div>
                    <?php ActiveForm::end(); ?>
                    <?php yii\widgets\Pjax::end() ?>
        </div>


    </div>

</div>
<script>
    // ajax call on select field:
    //get irrigation system which is assigned to field
    $(document).ready(function() {

        $('#field-fieldid').on('change', function() {
			
            var drop = $('#field-fieldid').val();

            jQuery.ajax({
                type: "GET",
                url: "test",
                data: "id=" + drop,
                dataType: "html",
                success: function(data)
                { 
					
                    var json = JSON.parse(data);
                    var id = json.field.id;
                    var name = json.field.name;
                    var fieldInputID = json.field.fieldInputID;
                    var fieldAddDate = json.field.fieldAddDate;
                    $('#field-fieldname').val(name);
                    $('#field-fieldinputid').val(fieldInputID);
                    $('#field-fieldadddate').val(fieldAddDate);
					
					$("#equipment-pkequipmentid").empty().append("<option value=''>Select Equipment</option>");
                    $.each(json.equipmentData, function(index, value) {

                        $("#equipment-pkequipmentid").append("<option value='" + index + "'>" + value + "</option>");

                    });

                }

            });
        });

        // ajax call on select field:
        //get equipment  which is assigned to irrigation system
		
        $('#equipment-pkequipmentid').on('change', function() {

            var drop = $('#equipment-pkequipmentid').val();

            jQuery.ajax({
                type: "GET",
                url: "getequipment",
                data: "id=" + drop,
                dataType: "html",
                success: function(data)
                { 
					 
                    var json = JSON.parse(data);
                    var id = json.field.id;
                    var name = json.field.name;
                    var fieldInputID = json.field.fieldInputID;
                    var fieldAddDate = json.field.fieldAddDate;
                    $('#field-fieldname').val(name);
                    $('#field-fieldinputid').val(fieldInputID);
                    $('#field-fieldadddate').val(fieldAddDate);
					
					$('#field-fieldid').val(id).change;
                    
                    
                },
				error: function (xhr, ajaxOptions, thrownError) {
					alert(xhr.status);
					alert(thrownError);
				}
            });

        });
		

    });

    function autoupdate() {

        var data = $('#test').val();
        $.ajax({type: "POST",
            url: "/create",
            data: 'data=' + data,
            cache: false,
            success: function(html)

            {

                $("#test").val('');

            }
        });

    }
</script>



