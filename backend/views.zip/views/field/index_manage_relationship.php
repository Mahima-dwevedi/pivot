<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchBank */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Manage Devices';
$this->params['breadcrumbs'][] = $this->title;
?>
<?php if (Yii::$app->user->identity->user_type === 'farm-admin')
{ ?>
    <div class="pull-right margin_top20 mobile_margin">
    <?= Html::a('Assign Device to Equipment', ['/field/assigndevice'], ['class' => 'btn btn-success']) ?>
    
    </div>
<?php } ?>


<div class="user-index">

    <div class="page-header">
        <div class="pull-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>          
    </div>
    <di v class="breadcrumbs">
        <ul>
            <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
            <li><span class="readcrum_without_link"><?=  $this->title?></span></li>
        </ul>
        <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>

<div class="row-fluid">
<?php \yii\widgets\Pjax::begin(['id' => 'farm-grid']); ?>   
    <div class="breadcrumbs" id="breadcrumbs-msg">

            <?php if ((Yii::$app->session->hasFlash('create')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('start')) || (Yii::$app->session->hasFlash('stop')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active')))
            { ?>
            <ul>
                <?php
                if (Yii::$app->session->getFlash('create'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . ADD_FIELD_SUCCESS . '</li>';
                }
                else if (Yii::$app->session->getFlash('update'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . ASSIGN_DEVICE_TO_EQUIP . '</li>';
                }
                else if (Yii::$app->session->getFlash('delete'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . DELETE_FIELD_SUCCESS . '</li>';
                }
                else if (Yii::$app->session->getFlash('error'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . ERROR_FIELD_SUCCESS . '</li>';
                }
                else if (Yii::$app->session->getFlash('stop'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . STOP_EQP_SUCCESS . '</li>';
                }
                else if (Yii::$app->session->getFlash('start'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . START_EQP_SUCCESS . '</li>';
                }
                ?>
            </ul>
<?php }
?>
    </div>
    <div class="search-form">
            <?php echo $this->render('_search', ['model' => $modelField]); ?>
    </div><!-- search-form -->

    <div class="box box-color box-bordered">
        <div class="box-title">
            <h3><i class="icon-reorder"></i><?= $this->title ?></h3>
            <!--<a class="btn pull-right" data-toggle="modal" href="#" id = "viewAll">View All</a>-->
        </div>
        <div class="clear"></div>

        <div class="box-content nopadding">
                <?php \yii\widgets\Pjax::begin(); ?>
            <form action="" name='farm-grid-list-form' id='farm-grid-list-form'>
			<div class="table-responsive">
                <?=
                GridView::widget([
                    'dataProvider' => $dataProvider,
                    'id' => 'farm-grid',
                    'columns' => [

                        ['class' => 'yii\grid\SerialColumn'],
                        [
                            'attribute' => 'fieldName',
                            'label' => 'Field Name',
                            'value' => function ($data)
                            {
                                return $data->field->fieldName; // $data['name'] for array data, e.g. using SqlDataProvider.
                            },
                        ],
                      /*  [
                            'attribute' => 'fkIrrigationID',
                            'label' => 'Irrigation System',
                            'value' => function ($data)
                            {
                                //   return $data->irrigationsystem->irrigationName; // $data['name'] for array data, e.g. using SqlDataProvider.
                                if (isset($data->irrigationsystem->irrigationName) && $data->irrigationsystem->irrigationName != '')
                                {

                                    $name = $data->irrigationsystem->irrigationName;
                                }
                                else
                                {
                                    $name = "not assigned";
                                } return $name;
                            },
                        ],*/
                        [
                            'attribute' => 'fkDeviceID',
                            'label' => 'Device Unit Number',
                            'value' => function ($data)
                            {
                                //   return $data->device->DeviceSerialNo;
                                if (isset($data->device->DeviceUnitNo) && $data->device->DeviceUnitNo != '')
                                {

                                    $name = $data->device->DeviceUnitNo;
                                }
                                else
                                {
                                    $name = "not assigned";
                                } return $name;
                            },
                        ],
                        [
                            'attribute' => 'EquipmentName',
                            'label' => 'Equipment Name',
                            'value' => function ($data)
                            {
                                return $data->EquipmentName; // $data['name'] for array data, e.g. using SqlDataProvider.
                            },
                        ],
                        [
                            'attribute' => 'fieldAddDate',
                            'label' => 'Device Created Date',
                            'value' => function ($data)
                            {
                                return  date("m-d-Y", strtotime($data->field->fieldAddDate)); // $data['name'] for array data, e.g. using SqlDataProvider.
                            },  
                        ],
                        [
                            'attribute' => 'fieldStatus',
                            'label' => 'Status',
                            'value' => function ($data)
                            {
                                return $data->field->fieldStatus; // $data['name'] for array data, e.g. using SqlDataProvider.
                            },
                        ],
                        [
                            'attribute' => 'PivotStopAction',
                            'label' => 'Current State',
                            'value' => function ($data)
                            {
                                if (isset($data->EqpStatus) && $data->EqpStatus != '')
                                {
                                    return $data->EqpStatus == 1 ? 'Started' : 'Stopped';
                                }
                                else
                                {
                                    $name = "Not Yet Started";
                                }return $name;
                            }
                        ],
                        [
                            'header' => 'Action',
                            'class' => 'yii\grid\ActionColumn',
                            'template' => ' {update} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {Start} {Stop}',
                            'buttons' => [
                                'deactivate' => function ($url, $model)
                                {
                                    return Html::a('<span class="glyphicon icon-ban-circle my_font_icon"></span>', $url, [
                                                'title' => Yii::t('app', 'deactivate'), 'data-pjax' => '0', 'data-confirm' => 'Are you sure you want to deactivate this account?',
                                            ]);
                                },
                                'Start' => function ($url, $model)
                                {
                                    return $model->EqpStatus == 0 && $model->fkFieldID != 0 && $model->fkIrrigationID != 0 && $model->fkDeviceID != 0 ? Html::a('<span class="glyphicon icon-play my_font_icon"></span>', $url."&type=".Yii::$app->controller->id."/".Yii::$app->controller->action->id, [
                                                'title' => Yii::t('app', 'Start'), 'data-pjax' => '0', "data-confirm" => "Are you sure you want to do START this equipment?"
                                            ]) : '';
                                },
                                'Stop' => function ($url, $model)
                                {

                                    return $model->EqpStatus == 1 ? Html::a('<span class="glyphicon icon-stop my_font_icon"></span>', $url, [
                                                'title' => Yii::t('app', 'Stop'), 'data-pjax' => '0',"data-confirm" => "Are you sure you want to do STOP this equipment?"
                                            ]) : '';
                                },
                                'activate' => function ($url, $model)
                                {
                                    return Html::a('<span class="glyphicon icon-ok my_font_icon"></span>', $url, [
                                                'title' => Yii::t('app', 'activate'), 'data-pjax' => '0', 'data-confirm' => 'Are you sure you want to activate this account?',
                                            ]);
                                },
                                'view' => function ($url, $model)
                                {
                                    return Html::a('<span class="glyphicon icon-eye-open my_font_icon"></span>', $url, [
                                                'title' => Yii::t('app', 'view'), 'data-pjax' => '0',
                                            ]);
                                },
                                'update' => function ($url, $model)
                                {
                                    return Yii::$app->user->identity->user_type == 'farm-admin' ? Html::a('<span class="glyphicon icon-pencil my_font_icon"></span>', $url, [
                                                'title' => Yii::t('app', 'update'), 'data-pjax' => '0',
                                            ]) : '';
                                },
                            ],
                            'urlCreator' => function ($action, $model, $key, $index)
                            {
                                if ($action === 'activate')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['farm/activate', 'id' => $model->field->fieldID, 'eqpid' => $model->pkEquipmentID]);
                                    //$url ='../../../view?slug='.$model->slug;
                                    return $url;
                                }
                                if ($action === 'deactivate')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['farm/deactivate', 'id' => $model->field->fieldID, 'eqpid' => $model->pkEquipmentID]);
                                    //$url ='../../../view?slug='.$model->slug;
                                    return $url;
                                }
                                if ($action === 'view')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['farm/view', 'id' => $model->field->fieldID, 'eqpid' => $model->pkEquipmentID]);
                                    return $url;
                                }
                                if ($action === 'update')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['field/update', 'id' => $model->field->fieldID, 'eqpid' => $model->pkEquipmentID]);

                                    return $url;
                                }
                                if ($action === 'Start')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['equipmentmeta/create', 'id' => $model->pkEquipmentID]);
                                    //$url ='../../../view?slug='.$model->slug;
                                    return $url;
                                }
                                if ($action === 'Stop')
                                {
                                    $url = Yii::$app->urlManager->createUrl(['equipmentmeta/stop', 'id' => $model->pkEquipmentID]);
                                    //$url ='../../../view?slug='.$model->slug;
                                    return $url;
                                }
                            }
                    ],
                        ],
                ]);
                ?>
			</div>
            <?= Html::endForm() ?>
<?php \yii\widgets\Pjax::end(); ?>

<?php echo common\components\PaginationField::widget(); ?>
        </div>

    </div>
</div>
