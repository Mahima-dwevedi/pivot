<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\ArrayHelper;
use app\models\admin;
use backend\models\farm;

/* @var $this yii\web\View */
/* @var $model app\models\cms */

$this->title = 'View Field';
$this->params['breadcrumbs'][] = ['label' => 'Farm', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

//$id=$model->fkCategoryID;
//$modelCombo = Category::find()->select('category_name')->where(['id' => $id])->asArray()->all();;
//$categoryName = $modelCombo[0][category_name];
?>
<div id="margin_mobile" class="page-header">
    <div class="pull-left">
        <h1><?= Html::encode($this->title) ?></h1>
    </div>
</div>
<?php //die('dsgd'); ?>
<div class="breadcrumbs">
    <ul>
        <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
        <li><?php echo Html::a('Manage Fields', ['/field']); ?><i class="icon-angle-right"></i></li>
        <li><span class="readcrum_without_link">View Field </span></li>
    </ul>
    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>


<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><?= $this->title ?></h3>
                <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/field'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
            </div> 
            <div class="box-content nopadding">
                <?=
                DetailView::widget([
                    'model' => $model,
                    'attributes' => [
                        [
                            'label' => 'Field Name',
                            'format' => 'raw',
                            'value' => $model->fieldName,
                        ],
                        [
                            'label' => 'Field ID',
                            'format' => 'raw',
                            'value' => $model->fieldInputID,
                        ],
                        [
                            'label' => 'Field Street Address',
                            'format' => 'raw',
                            'value' => $model->fieldAddress1,
                        ],
                        [
                            'label' => 'Field City',
                            'format' => 'raw',
                            'value' => $model->fieldAddress2,
                        ],
                        [
                            'label' => 'Field State Name',
                            'value' => $model->state->state == NULL ? "N/A" : $model->state->state,
                        ],
                        [
                            'label' => 'Field Pincode',
                            'format' => 'raw',
                            'value' => $model->fieldPincode,
                        ],
                        [
                            'label' => 'Owner/Landlord Name',
                            'format' => 'raw',
                            'value' => $model->fieldOwner,
                        ],
                        [
                            'label' => 'Owner/Landlord Street Address',
                            'format' => 'raw',
                            'value' => $model->fieldOwnerAddress1,
                        ],
                        [
                            'label' => 'Owner/Landlord City Name',
                            'value' => $model->fieldOwnerAddress2,
                        ],
                        [
                            'label' => 'Owner/Landlord State Name',
                            'value' => $model->ownerState == NULL ? "N/A" : $model->ownerState->state,
                        ],
                        [
                            'label' => 'Owner/Landlord Pincode',
                            'format' => 'raw',
                            'value' => $model->Pincode,
                        ],
                        [
                            'label' => 'Owner/Landlord Phone',
                            'format' => 'raw',
                            'value' => $model->fieldOwnerPhone,
                        ],
                        [
                            'label' => 'Owner/Landlord Email',
                            'format' => 'raw',
                            'value' => $model->fieldOwnerEmail,
                        ],
                    ],
                ])
                ?>

            </div>

        </div>
    </div>
</div>

