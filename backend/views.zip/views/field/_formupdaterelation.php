<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;
use yii\helpers\ArrayHelper;
use backend\models\Irrigationsystem;
use backend\models\Field;
use backend\models\Equipment;
use backend\models\Device;

/* @var $this yii\web\View */
/* @var $model app\models\Farm */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="row-fluid">
    <div class="breadcrumbs" id="breadcrumbs-msg">

        <?php if ((Yii::$app->session->hasFlash('errorupdate')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active'))) { ?>
            <ul>
                <?php
                if (Yii::$app->session->getFlash('create')) {
                    echo '<li><span class="readcrum_without_link_success">' . ADD_DEVICE_SUCCESS . '</li>';
                } else if (Yii::$app->session->getFlash('update')) {
                    echo '<li><span class="readcrum_without_link_success">' . ASSIGN_DEVICE_SUCCESS . '</li>';
                } else if (Yii::$app->session->getFlash('delete')) {
                    echo '<li><span class="readcrum_without_link_success">' . DELETE_FIELD_SUCCESS . '</li>';
                } else if (Yii::$app->session->getFlash('error')) {
                    echo '<li><span class="readcrum_without_link_success">' . ERROR_FIELD_SUCCESS . '</li>';
                } else if (Yii::$app->session->getFlash('errorupdate')) {
                    echo '<li><span class="readcrum_without_link_success">' . FIELD_ASSIGN_ERROR . '</li>';
                }
                ?>						
            </ul>
        <?php }
        ?>
    </div>

    <div class="box box-color box-bordered">
        <div class="box-title">
            <h3><i class="icon-table"></i><?= Html::encode($this->title) ?></h3>
            <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/field/index_relationship'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
        </div>
        <div class="box-content nopadding">
            <?php yii\widgets\Pjax::begin(['id' => 'farm-gird']) ?>
            <?php
            $form = ActiveForm::begin([
                        'id' => 'farm-form',
                        'enableAjaxValidation' => false,
                        'options' => [
                            'class' => 'form-horizontal form-bordered form-validate',
                        ],
            ]);
            ?>
            
            <div class="control-group">
                <?= Html::activeLabel($modelEquipment, 'pkEquipmentID', ['label' => 'Equipment Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                <div class="controls">   
                    <?php
                    $id = Yii::$app->user->id;
                    $fieldModel=new Field;
                    $resultModel=$fieldModel->getEquipmentUpdate($id,$_GET['eqpid']);
                    $listData = ArrayHelper::map($resultModel, 'pkEquipmentID', 'EquipmentName');
                    echo $form->field($modelEquipment, 'pkEquipmentID')->dropDownList($listData, ['prompt' => 'Equipment Name'])->label(false);
                    ?>	     
                </div>
            </div>
            <div class="control-group">
                <?= Html::activeLabel($modelDevice, 'pkDeviceID', ['label' => 'Device Unit Number', 'class' => 'control-label']) ?>
                <div class="controls">   
                    <?php  
                    $id = Yii::$app->user->id;
                    $fieldModel=new Field;
                    $resultModel=$fieldModel->getDeviceUpdate($id,$_GET['eqpid']);
                    $listData = ArrayHelper::map($resultModel, 'pkDeviceID', 'DeviceUnitNo');
                    $modelDevice->pkDeviceID=$modelEquipment->fkDeviceID;
                    echo $form->field($modelDevice, 'pkDeviceID')->dropDownList($listData, ['prompt' => 'Select Device'])->label(false);
                    ?>	     
                </div>
            </div>
            <div class="note "><strong>Note :</strong> <span class="required">*</span> Indicates mandatory fields.</div>
            <div class="form-actions ">
                <?= Html::submitInput($model->isNewRecord ? 'Update' : 'Assign', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                <?php echo Html::a('Cancel', array('/field/index_relationship'), array('class' => 'btn')); ?>  
            </div>
            <?php ActiveForm::end(); ?>
            <?php yii\widgets\Pjax::end() ?>
        </div>


    </div>

</div>
<script>

    function autoupdate() {

        var data = $('#test').val();

        $.ajax({type: "POST",
            url: "/create",
            data: 'data=' + data,
            cache: false,
            success: function(html)

            {

                $("#test").val('');

            }
        });

    }
</script>


