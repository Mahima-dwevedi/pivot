<script type="text/javascript">
 function fieldMultipleAction(action){ 
        var checked_num = $('input[name="id[]"]:checked').length;
        if (!checked_num) {
            alert('Please select atleast one record.');
            $.pjax.reload({container:'#farm-grid'})
            $(document).on('pjax:complete', function(){
               // $("#contactStatus").select2();
            });
            
            } else {
	    if(confirm('Are you sure you want to delete this item?')) {
              if ($('#field').val()=='Select') {
                    alert('Please Select valid option');
                } else {
                        
                    var data=$("#farm-grid-list-form").serialize();
                  // alert(data);return false;
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo Yii::$app->getUrlManager()->createUrl("field/multipledelete"); ?>',
                        data:data,
                        success:function(data){
                           if(data)
                            {
                                var statusMsg = "";
                                statusMsg = 'Field  has been deleted successfully.';
                                $('#message').html("<div class='breadcrumbs' id='breadcrumbs-msg'><ul><li><span class='readcrum_without_link_success'>"+statusMsg+"</span></li></ul></div>");
                                $('#breadcrumbs-msg').fadeOut(7000);
                                $.pjax.reload({container:'#farm-grid'});
                                $(document).on('pjax:complete', function(){
                                  //  $("#contactStatus").select2();
                                });
                                statusMsg = '';
                            }
                        },error: function(data) { // if error occured
                            alert("Error occured.Please try again.");
                            $.pjax.reload({container:'#farm-grid'});
                            $(document).on('pjax:complete', function(){
                             //   $("#contactStatus").select2();
                            });
                        },
                        dataType:'html'
                    });
			        
                }
            
               }else {
                $.pjax.reload({container:'#farm-grid'});
                $(document).on('pjax:complete', function(){
                  //  $("#bannerStatus").select2();
                });
            }
          }     
        }   
    
  </script>
