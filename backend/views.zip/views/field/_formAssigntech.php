<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use backend\models\Fieldtechnician;
use backend\models\Field;


/* @var $this yii\web\View */
/* @var $model app\models\Farm */
/* @var $form yii\widgets\ActiveForm */
?>
<?php // print_r($listData); die;     ?>
<div class="row-fluid">
    <div class="breadcrumbs" id="breadcrumbs-msg">

        <?php if ((Yii::$app->session->hasFlash('errorupdate')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active'))|| (Yii::$app->session->hasFlash('errormultiple'))) { ?>
            <ul>
                <?php
                if (Yii::$app->session->getFlash('create')) {
                    echo '<li><span class="readcrum_without_link_success">' . ASSIGN_FIELD_SUCCESS . '</li>';
                } else if (Yii::$app->session->getFlash('update')) {
                    echo '<li><span class="readcrum_without_link_success">' . ASSIGN_DEVICE_SUCCESS . '</li>';
                } else if (Yii::$app->session->getFlash('delete')) {
                    echo '<li><span class="readcrum_without_link_success">' . DELETE_FIELD_SUCCESS . '</li>';
                } else if (Yii::$app->session->getFlash('error')) {
                    echo '<li><span class="readcrum_without_link_success">' . ERROR_FIELD_SUCCESS . '</li>';
                } else if (Yii::$app->session->getFlash('errorupdate')) {
                    echo '<li><span class="readcrum_without_link_success">' . FIELD_ASSIGN_ERROR . '</li>';
                }
                else if (Yii::$app->session->getFlash('errormultiple')) {
                    echo '<li><span class="readcrum_without_link_error">' . FIELD_MULTIPLE_ERROR . '</li>';
                }
                ?>						
            </ul>
        <?php }
        ?>
    </div>

    <div class="box box-color box-bordered">
        <div class="box-title">
            <h3><i class="icon-table"></i><?= Html::encode($this->title) ?></h3>
            <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/fieldtechnician/index'); ?>"><i class="icon-circle-arrow-left"></i>Back</a>
        </div>
        <div class="box-content nopadding">
            <?php yii\widgets\Pjax::begin(['id' => 'farm-gird']) ?>
            <?php
            $form = ActiveForm::begin([
                        'id' => 'farm-form',
                        'enableAjaxValidation' => false,
                        'options' => [
                            'class' => 'form-horizontal form-bordered form-validate',
                        ],
            ]);
            ?>
              <div class="control-group">
                <?= Html::activeLabel($model, 'fkTechnicianID', ['label' => 'Field Technician Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                <div class="controls">   
                    <?php
                     $id = Yii::$app->user->id; 
                     
                      if(Yii::$app->user->identity->Adminlevel == '0'){ // Condition to check field according to level Date:5-8-2015
  $modelFieldtech = Fieldtechnician::find()->joinWith(['admin'])->where(['admin.fkUserID' => $id])->orWhere(['tbl_technician.fkParentID' => $id])->all();
                                 
  }else{
     $modelFieldtech = Fieldtechnician::find()->joinWith(['admin'])->where(['admin.fkUserID' => $id])->orWhere(['tbl_technician.fkParentID' => \Yii::$app->user->identity->fkUserID])->all();
                                   }
                    
                  //  $modelFieldtech = Fieldtechnician::find()->joinWith(['admin'])->where(['admin.fkUserID'=>$id])->all();
                    $listData = ArrayHelper::map($modelFieldtech, 'pkTechnicianID', 'FeildtechName');
                    echo $form->field($model, 'fkTechnicianID')->dropDownList($listData,['prompt' => 'Select Field Technician'])->label(false);
                    ?>	     
                </div>
            </div>
            
            <div id="test"></div>
          <div  iv class="control-group">
                <?= Html::activeLabel($model, 'fkFieldID', ['label' => 'Field Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                <div class="controls">   
                    <?php
                    $id = Yii::$app->user->id; 
                 //   $modelField = Field::find()->where(['fkFarmID' => \Yii::$app->user->id])->all();
                  if(Yii::$app->user->identity->Adminlevel == '0'){ // Condition to check field according to level Date:5-8-2015
    $modelField = Field::find()->where(['fkFarmID' => \Yii::$app->user->id])->orWhere(['fkParentID' =>\Yii::$app->user->id])->all();
                   
  }else{
      $modelField = Field::find()->where(['fkFarmID' => \Yii::$app->user->id])->orWhere(['fkParentID' =>\Yii::$app->user->identity->fkUserID])->all();
                    }
                    
                    
                    
                    $listData = ArrayHelper::map($modelField, 'fieldID', 'fieldName');
                    echo $form->field($model, 'fkFieldID[]')->dropDownList($listData,  ['multiple' => true], ['prompt' => 'Select'], array('id' => 'dropId'))->label(false);
                    ?>	     
                </div>
            </div>
            <div class="note "><strong>Note :</strong> <span class="required">*</span> Indicates mandatory fields.</div>
            <div class="form-actions ">
                <?= Html::submitInput($model->isNewRecord ? 'Assign' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                <?php echo Html::a('Cancel', array('/field/index'), array('class' => 'btn')); ?>  
            </div>
            <?php ActiveForm::end(); ?>
            <?php yii\widgets\Pjax::end() ?>
        </div>


    </div>

</div>
<script type="text/javascript">
    $(document).ready(function() {
        $("#technicianfieldrelation-fktechnicianid").change(function() {
            if ($(this).val()) {
                loadField($(this).val());
            }
        });

    });

    function loadField(id) {
        $.ajax
                ({
                    type: "POST",
                    url: "<?php echo Yii::$app->getUrlManager()->createUrl("field/ajax-field"); ?>",
                    data: "id=" + id,
                    async: false,
                    success: function(msg)
                    {
                        var obj = jQuery.parseJSON(msg);
                        var result = $.map(obj, function(value, key) {
                            return [key];
                        });
                        //console.log(result);
                        $('#technicianfieldrelation-fkfieldid option:selected').attr('selected', false);
                        $('#technicianfieldrelation-fkfieldid').val(result);

                    },
                });
    }
</script>
