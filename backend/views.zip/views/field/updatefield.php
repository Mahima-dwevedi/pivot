<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\user */

$this->title = 'Update Field';
$this->params['breadcrumbs'][] = ['label' => 'Fields', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->fieldID, 'url' => ['view', 'id' => $model->fieldID]];
$this->params['breadcrumbs'][] = 'Update';
?>
<?php //die('asf'); ?>
<div id="margin_mobile" class="page-header">
    <div class="pull-left">
        <h1> <?= Html::encode($this->title) ?></h1>
    </div>
</div>
<div class="breadcrumbs">
    <ul>
        <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
        <li><?php echo Html::a('Manage fields', ['/field']); ?><i class="icon-angle-right"></i></li>
        <li><span class="readcrum_without_link">update Field</span></li>
    </ul>
    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>
<?=
$this->render('_formupdate', [
    'model' => $model,
    'modelIrrigation' => $modelIrrigation,
])
?>

<script>
    $(document).ready(function() {
        if ($("#field-fieldselectowner").prop("checked") == true) {
            $("#ownerid").show();
        }

    });
</script>