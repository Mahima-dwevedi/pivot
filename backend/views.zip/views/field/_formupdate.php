<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;
use yii\helpers\ArrayHelper;
use backend\models\Irrigationsystem;
use backend\models\State;

/* @var $this yii\web\View */
/* @var $model app\models\Farm */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="row-fluid">
    <div class="breadcrumbs" id="breadcrumbs-msg">
        <?php
        if ((Yii::$app->session->hasFlash('create'))) {
            ?>
            <ul>
                <?php
                if (Yii::$app->session->getFlash('create')) {
                    echo '<li><span class="readcrum_without_link_success">' . ADD_IRRIGATION_SUCCESS . '</li>';
                }
                ?>						
            </ul>
        <?php }
        ?>
    </div>
    <div class="">
        <div class="box box-color box-bordered">
            <!--             <div class="breadcrumbs" id="breadcrumbs-msg">
                            <span class="error"><?php echo Yii::$app->session->getFlash('unique'); ?></span>
                        </div>-->
            <div class="box-title">
                <h3><i class="icon-table"></i><?= Html::encode($this->title) ?></h3>
                <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/field'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
            </div>
            <div class="box-content nopadding">
                <?php yii\widgets\Pjax::begin(['id' => 'farm-gird']) ?>
                <?php
                $form = ActiveForm::begin([
                            'id' => 'farm-form',
                            'enableAjaxValidation' => false,
                            'options' => [
                                'class' => 'form-horizontal form-bordered form-validate',
                            ],
                ]);
                ?>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'fieldName', ['label' => 'Field Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'fieldName', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                        </div>
                    </div>

                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'fieldInputID', ['label' => 'Field ID<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'fieldInputID', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>

                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'fieldAddress1', ['label' => 'Field Street Address<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'fieldAddress1', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'fieldAddress2', ['label' => 'Field City', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'fieldAddress2', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="control-group">
                    <?= Html::activeLabel($model, 'fkFieldstateID', ['label' => 'State Name', 'class' => 'control-label']) ?>
                    <div class="controls">   
                        <?php
                        echo $form->field($model, 'fkFieldstateID')->dropDownList(
                                ArrayHelper::map(state::find()->all(), 'pkStateID', 'state'), ['prompt' => 'Select State Name'])->label(false);
                        ?>
                    </div>
                </div><div class="cb"></div> 
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'fieldPincode', ['label' => 'Field Zip code<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'fieldPincode', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                        </div>

                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'fieldSelectowner', ['label' => 'Add Landlord Information', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?php echo $form->field($model, 'fieldSelectowner')->checkbox(array('label' => ' Add Landlord Information'))->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="owner" id="ownerid"  style="display:none">
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'fieldOwner', ['label' => 'Owner/Landlord Name', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'fieldOwner', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'fieldOwnerAddress1', ['label' => 'Owner/Landlord Street Address', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'fieldOwnerAddress1', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'fieldOwnerAddress2', ['label' => 'Owner/Landlord City', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'fieldOwnerAddress2', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'fkStateID', ['label' => 'State Name', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?php
                            echo $form->field($model, 'fkStateID')->dropDownList(
                                    ArrayHelper::map(state::find()->all(), 'pkStateID', 'state'), ['prompt' => 'Select State Name'])->label(false);
                            ?>

                        </div>
                    </div><div class="cb"></div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'Pincode', ['label' => 'Zip code', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'Pincode', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                            </div>

                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'fieldOwnerPhone', ['label' => 'Owner/Landlord Phone', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'fieldOwnerPhone', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'fieldOwnerEmail', ['label' => 'Owner/Landlord Email', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'fieldOwnerEmail', ['errorOptions' => ['class' => 'error']])->textInput()->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                </div>
                <?php // echo "<pre>";print_r($modelIrrigation); ?>
                <!--                 <div class="fullwidth">
                                        <div class="control-group">
                <?php //= Html::activeLabel($model, 'irrigationID', ['label' => 'Irrigation System', 'class' => 'control-label'])  ?>
                                            <div class="controls">
                <?php //= $form->field($model, 'irrigationID', ['errorOptions' => ['class' => 'error']])->dropDownList($modelIrrigation,['multiple'=>true])->label(false); ?>
                                            </div>
                                        </div>
                                        <div class="cb"></div>
                                        
                                    </div>-->
                <div class="note"><strong>Note :</strong> <span class="required">*</span> Indicates mandatory fields.</div>

                <div class="form-actions">
                    <?= Html::submitButton($model->isNewRecord ? 'Add Field' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    <?php echo Html::a('Cancel', array('/field'), array('class' => 'btn')); ?>
                </div>
                <?php ActiveForm::end(); ?>
                <?php yii\widgets\Pjax::end() ?>

            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        //set initial state.
        $('#field-fieldselectowner').click(function() {
            if ($(this).is(":checked")) {

                $('#ownerid').css('display', 'block');
            }
            else {
                $('#ownerid').css('display', 'none');
            }
        });
        $(function(){
            $("#field-fieldownerphone").mask("999-999-9999");
        });

        function autoupdate() {

            var data = $('#test').val();

            $.ajax({type: "POST",
                url: "/create",
                data: 'data=' + data,
                cache: false,
                success: function(html)

                {

                    $("#test").val('');

                }
            });
        }
    });



</script>