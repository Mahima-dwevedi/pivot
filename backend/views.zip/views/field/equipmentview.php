<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\ArrayHelper;
use app\models\admin;
use backend\models\device;

/* @var $this yii\web\View */
/* @var $model app\models\cms */

$this->title = 'Manage Fields Equipment';
$this->params['breadcrumbs'][] = ['label' => 'Field', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

//$id=$model->fkCategoryID;
//$modelCombo = Category::find()->select('category_name')->where(['id' => $id])->asArray()->all();;
//$categoryName = $modelCombo[0][category_name];
?>
<div id="margin_mobile" class="page-header">
    <div class="pull-left">
        <h1><?= Html::encode($this->title) ?></h1>
    </div>
</div>

<div class="breadcrumbs">
    <ul>
        <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
        <li><?php echo Html::a('List of all fields', ['/field']); ?><i class="icon-angle-right"></i></li>
        <li><span class="readcrum_without_link">Manage Fields Equipment</span></li>
    </ul>
    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>
<?php //echo "<pre>";print_r($model);die;?>

<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3>Manage Fields Equipment</h3>
                <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/field'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
            </div>
            <div class="box-content nopadding">
                <?php
                $equipment = Yii::$app->db->createCommand
                        ("SELECT p.pkEquipmentID,p.fkFieldID,p.EquipmentName,p.Longitude,p.Latitude,p.EquipmentType, p.EqpModel
          as 'tbl_equipment'
          FROM `tbl_equipment` p, tbl_field pd 
          where pd.fieldID=p.fkFieldID 
          and p.fkFieldID=$model->fieldID");
                $equipments = $equipment->queryAll();
                if (!empty($equipments)) {
                    echo '<table class="table table-striped table-bordered table-hover">';
                    echo "<tr><th>Equipment Name</th><th>Longitude</th><th>Latitude</th><th>Equipment Type</th><th>Equipment Model</th></tr>";


                    foreach ($equipments as $equipment) {
                        echo "<tr><td>";
                        echo $equipment['EquipmentName'];
                        echo "</td><td>";
                        echo $equipment['Longitude'];
                        echo "</td><td>";
                        echo $equipment['Latitude'];
                        echo "</td><td>";
//                        echo $equipment['EquipmentType'];
                        switch($equipment['EquipmentType']){
                            case 0:
                                echo "Pivot";
                                break;
                            case 1:
                                echo "Water Pump";
                                break;
                            case 2:
                                echo "28  Pump";
                                break;
                        }
                        echo "</td><td>";

                        $d = $equipment['tbl_equipment'];
                        echo $d;

                        echo "</td></tr>";
                    }//   print_r($package['tbl_equipment']); die;
                } else {
                    $d = 0;
                    ?>
                    <div class="control-group" id="w1">
                        <div class="empty">No equipment has been assigned to this field.</div>
                    </div>

                    <?php
                }
                ?>
                </table>
            </div>

        </div>
    </div>
</div>
