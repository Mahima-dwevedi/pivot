<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

$this->title = 'Sign In';
//$this->params['breadcrumbs'][] = $this->title;
?>
<div class="pivot">
    <div class="float-left1">
        <h3 class="text-muted pull-left"><img src="<?php echo Yii::$app->getUrlManager()->getBaseUrl(); ?>/img/Final-logo200.png" alt="" /></h3>
    </div>
    <div  class="float-right1">
        <?php echo date('m-d-Y h:i:s A'); //date("jS  F Y h:i:s A"); ?>
    </div>
</div>                 
<div class="wrapper">
    <h1><a><?= strtoupper("Pivot Pro"); ?></a></h1>

    <div class="login-body">
        <h2>SIGN IN</h2>
        <div class="breadcrumbs" id="breadcrumbs-msg">
            <?php
            if (Yii::$app->params['loginPageMessage'] != '')
            {
                ?>
            <ul><li><span class="readcrum_without_link_success login-sucess-msg"><?php echo Yii::$app->params['loginPageMessage']; ?></span></li></ul>
            <?php } ?>
            <?php
            if ((Yii::$app->session->hasFlash('success')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('editprofile')))
            {
                ?>
                <ul>
                    <?php
                    if (Yii::$app->session->getFlash('success'))
                    {
                        echo '<li><span class="readcrum_without_link_success login-sucess-msg">' . Yii::$app->session->getFlash('success') . '</li>';
                    }
                    ?>
                </ul>
            <?php } ?>

        </div>

        <?php $form = ActiveForm::begin(['id' => 'login-form', 'class' => 'form-validate']); ?>
        <div class="control-group">
            <div class="email controls">
                <?= $form->field($model, 'email')->textInput(['placeholder' => 'Email ID', 'value' => $username, 'class' => 'input-block-level', 'size' => 60, 'maxlength' => 150])->label(false); ?>
            </div>
        </div>
        <div class="control-group">
            <div class="pw controls">
                <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Password', 'value' => $password, 'class' => 'input-block-level', 'size' => 60, 'maxlength' => 150])->label(false); ?>
            </div>
        </div>
        <div class="control-group">
            <div class="remember remember_chk">
                <?php $model->rememberMe = $remember; ?>
                <?=
                $form->field($model, 'rememberMe')->checkBox(['label' => 'remember', 'data-skin' => 'square', 'data-color' => 'blue',
                    'uncheck' => '0', 'checked' => '1'])->label(true);
                ?>
            </div>
        </div>
        <div class="submit" align="center">
            <?php echo Html::submitButton('Sign In', ['class' => 'btn btn-primary']); ?>
        </div>
        <?php ActiveForm::end(); ?>
        <div class="forget">
            <?= Html::a('Forgot password?', ['site/recovery']) ?>
        </div>
    </div>
</div>
