<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Settings';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div id="margin_mobile" class="page-header">
    <div class="pull-left">
        <h1>Edit Profile</h1>
    </div>			
</div>

<div class="breadcrumbs">
    <ul>
        <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
        <li><span class="readcrum_without_link">Edit Profile</span></li>
    </ul>
    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>


<div class="breadcrumbs" id="breadcrumbs-msg">
    <?php
    if ((Yii::$app->session->hasFlash('editProfileSuccess')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('editprofile')))
    {
        ?>
        <ul>
            <?php
            if (Yii::$app->session->getFlash('editProfileSuccess'))
            {
                echo '<li><span class="readcrum_without_link_success">' . EDIT_PROFILE_UPDATE . '</li>';
            }
            else if (Yii::$app->session->getFlash('update'))
            {
                echo '<li><span class="readcrum_without_link_success">' . EDIT_CMS_SUCCESS . '</li>';
            }
            else if (Yii::$app->session->getFlash('editprofile'))
            {
                echo '<li><span class="readcrum_without_link_success">' . EDIT_PROFILE_UPDATE . '</li>';
            }
            ?>
        </ul>
    <?php } ?>
</div>

<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3>Edit Profile</h3>
            </div>
            <div class="box-content nopadding">


                <?php
                $form = ActiveForm::begin([
                            'id' => 'changepassword-form',
                            'enableAjaxValidation' => false,
                            'options' => [
                                'class' => 'form-horizontal form-bordered'],
                        ]);
                ?>
                <div class="control-group">
                    <?= Html::activeLabel($model, 'username', ['label' => 'Name <span class="required">*</span>', 'class' => 'control-label']) ?>

                    <div class="controls">
                        <?= $form->field($model, 'username')->textInput()->label(false); ?>

                    </div>
                </div>
                <div class="control-group">
                    <?= Html::activeLabel($model, 'phone', ['label' => 'Phone <span class="required">*</span>', 'class' => 'control-label']) ?>

                    <div class="controls">
                        <?= $form->field($model, 'phone')->textInput(['placeholder' => '111-111-1111'])->label(false); ?>

                    </div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'email', ['label' => 'Email Address<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'email', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Email Address'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'confirm_email', ['label' => 'Reconfirm Email Address<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'confirm_email', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Email Address','value'=>$model->email])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>  





                <div class="note"><strong>Note :</strong> <span class="required">*</span> Indicates mandatory fields.</div>
                <div class="form-actions">
                    <?= Html::submitButton('Submit', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    <?php echo Html::a('Cancel', array('/site/index'), array('class' => 'btn')); ?>
                </div>


                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
 $(function(){
    $("#admin-phone").mask("999-999-9999");
 });
</script>