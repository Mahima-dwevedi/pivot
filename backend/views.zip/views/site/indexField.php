<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use yii\widgets\DetailView;
use backend\models\Farm;

$this->title = 'Home';
?>
<div id="margin_mobile" class="page-header">
    <div class="pull-left">
        <h1>Home</h1>
    </div>
</div>
<div class="breadcrumbs">
    <ul>
       <li><span class="readcrum_without_link">Home</span></li>
    </ul>
    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>
<div class="row-fluid">
    <div class="span12">
        <div class="box box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-table"></i>Last Login Details</h3>
            </div>
            <div class="box-content nopadding">
                <table class="table table-hover table-nomargin table-bordered">
                    <table class="table table-hover table-nomargin table-bordered">
                        <thead>
                            <tr>
                                <th>Last Login</th>

                                <th class='hidden-350'>Contact</th>
                            </tr>
                            <tr>
                                <td><?php echo Date('m-d-Y  h:i:s',strtotime(Yii::$app->user->identity['AdminLastLogin']));//Yii::$app->user->identity['AdminLastLogin']; ?></td>

                                <td><?php echo Yii::$app->user->identity['phone']; ?></td>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </table>
            </div>
            
        </div>
    </div>
</div>
<?php if ($dataProvider) { ?>
    <div class="row-fluid">
        <div class="span12">
            <div class="box box box-color box-bordered">
                <div class="box-title">
                    <h3><i class="icon-table"></i>Alerts</h3>
                </div>
                <div class="box-content nopadding">
                    <table class="table table-hover table-nomargin table-bordered">
                        <table class="table table-hover table-nomargin table-bordered">
                            <thead>
                                <tr>
                                    <th>Equipment Name</th>
                                    <th>Message</th>
                                    <th>Time</th>
                                    <th>Status</th>

                                </tr>
                                <?php
                                foreach ($dataProvider as $valueDate) {
                                    ?>
                                    <tr>
                                        <td><?= $valueDate['EquipmentName'] ?></td>
                                        <td><?= $valueDate['EquipmentNotificationMessage'] ?></td>
                                        <td><?= date('m-d-Y H:i:s', strtotime($valueDate['EquipmentNotificationSendTime'])) ?></td>
                                        <td><?= $valueDate['EquipmentNotificationStatus'] == '1' ? Html::a('Attend', ['/site/attend?id=' . $valueDate['pkEquipmentNotificationID']]) : 'Attended' ?></td>
                                    </tr>
                                <?php }
                                ?>

                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </table>
                </div>
            </div>
        </div>
    </div>
     <?php echo common\components\PaginationField::widget(); ?>
<?php } ?>
