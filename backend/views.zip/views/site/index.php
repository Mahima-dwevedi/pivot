<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use yii\widgets\DetailView;
use backend\models\Farm;

$this->title = 'Home';
?>
<div id="margin_mobile" class="page-header">
    <div class="pull-left">
        <h1>Home</h1>
    </div>
       
</div>
<div class="breadcrumbs">
    <ul>
       <li><span class="readcrum_without_link">Home</span></li>
    </ul>

    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>
<div class="row-fluid">
    <div class="span12">
        <div class="box box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-table"></i>Last Login Details</h3>
            </div>
            <div class="box-content nopadding">
                <table class="table table-hover table-nomargin table-bordered">
                    <table class="table table-hover table-nomargin table-bordered">
                        <thead>
                            <tr>
                                <th>Login At</th>

                                <th class='hidden-350'>Contact</th>
                            </tr>
                            <tr>
                                <td><?php echo Date('m-d-Y h:i:s a',strtotime(Yii::$app->user->identity['AdminLastLogin'])); ?></td>

                                <td><?php echo Yii::$app->user->identity['phone']; ?></td>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table> 
                    <tbody>

                    </tbody>
                </table>
            </div>
             <?php if($model){ ?>
            <div class="box box-color box-bordered">
               
                <div class="box-title">
                    <h3>Farm Account</h3>
                    <
                </div>
                <div class="box-content nopadding">

                    <?=
                    DetailView::widget([
                        'model' => $model,
                        'attributes' => [
                            [
                                'label' => 'Recently Create Account',
                                'format' => 'raw',
                                'value' => $model->Name,
                            ],
                            [
                                'label' => 'Email ID',
                                'format' => 'raw',
                                'value' => $model->admin->email,
                            ],
                            [
                                'label' => 'Contact Number',
                                'format' => 'raw',
                                'value' => $model->admin->phone,
                            ],
                        ],
                    ])
                    ?>

                </div>

            </div>
            <?php echo common\components\PaginationField::widget(); ?>
             <?php }?>
        </div>
    </div>
</div>