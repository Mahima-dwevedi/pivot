<?php

use yii\helpers\Html;
use yii\helpers\Url;

$imagePath = Yii::$app->request->BaseUrl;
$baseUrl = Url::base();
$default = "N/A";
$lat_log = $model['Latitude'] == "" ? $default : $model['Latitude'] . "," . $model['Longitude'];
$googleMapURL = "https://www.google.com/maps/place/" . $lat_log;
$equipStartTime = $model['startDate'] == "" ? $default : date('m-d-Y H:i:s', strtotime($model['startDate']));
$this->title = "View Summary";
?>
<div class="row-fluid">
    <div class="span12 top_division">
        <div class="box box-color box-bordered">
            <div id="message">
            </div>
            <div class="box-title">
                <h3>Equipment Information</h3>
            </div>
            <div class="box-content nopadding">

                <table class="table table-striped table-bordered detail-view">
                    <tbody>
                        <tr><th>Equipment Name :</th><td><?= $model['EquipmentName'] == "" ? $default : $model['EquipmentName'] ?></td></tr>
                        <tr><th>Latitude , Longitude (Map Link):</th><td><a href="<?= $googleMapURL ?>"><?= $lat_log ?></a></td></tr>
						<tr>
							<th>Send Location via Text Message:</th>
							<td>
								<?
									$iPod    = stripos($_SERVER['HTTP_USER_AGENT'],"iPod");
									$iPhone  = stripos($_SERVER['HTTP_USER_AGENT'],"iPhone");
									$iPad    = stripos($_SERVER['HTTP_USER_AGENT'],"iPad");
									$Android = stripos($_SERVER['HTTP_USER_AGENT'],"Android");
									
									if ( $iPod || $iPhone || $iPad){
										echo "<a href=\"sms:&body=" . $googleMapURL . "\">Launch Message App</a>";
									}else if($Android) {
										echo "<a href=\"sms:?body=" . $googleMapURL . "\">Launch Message App</a>";
									}else {	
										echo "Device Not Supported";
									}
								?>
							</td>
						</tr>
                        <tr><th>Pressure :</th><td>

                                <?php
                                if ($pressure != "")
                                {
                                    echo $pressure == "1" ? "Yes" : "No";
                                }
                                else
                                {
                                    echo "N/A";
                                }
                                ?>
                            </td></tr>
                        <tr><th>Equipment Start Time :</th><td><?= $equipStartTime ?></td></tr>
                        <tr><th>Equipment Stop Time :</th><td><?= $lastStopTime ?></td></tr>
                        <tr><th>Pivot Last Report Time :</th><td><?= $lastReportTime == "" ? $default : date('m-d-Y H:i:s', strtotime($lastReportTime)) ?></td></tr>
                        <!--<tr><th>Device Battery Strength :</th><td><?= $default ?></td></tr>-->
                        <tr><th>Device Cellular Strength :</th><td><?= $signalStrength == "" ? $default : $signalStrength ?></td></tr>
                        <!--<tr><th>28% actual Strength :</th><td><?= $default ?></td></tr>-->	 
                        <tr><th>Pivot Position :</th><td><?= $position == "" ? $default : $position ?></td></tr>
                        <tr><th>Watering Chart :</th><td>
                            <?php if(!empty($model['EqpWateringChart']))
                            { ?>
                                <a data-pjax='0' target="_blank" href="<?php echo $baseUrl;?>/uploaded_files/water_chart/<?php echo $model['EqpWateringChart'];?>">Watering Chart</a>
                                <?php }?></td></tr>
                        <tr><th>Pivot Instructions :</th><td>
                            <?php if(!empty($model['pivotInstructions']))
                            { ?><a data-pjax='0' target="_blank" href="<?php echo $baseUrl;?>/uploaded_files/pivot_instruction/<?php echo $model['pivotInstructions'];?>">Pivot Instructions</a>
                        <?php }?></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div id="message">
            </div>
            <div class="box-title">
                <h3>Startup Info (User Entered)</h3>
            </div>
            <div class="box-content nopadding">

                <table class="table table-striped table-bordered detail-view">
                    <tbody>
                        <tr><th>28% Desired Rate :</th><td><?= $model['DesiredRate'] == null ? $default : $model['DesiredRate'] ?></td></tr>
                        <tr><th>28% Tank level :</th><td><?= $model['TankLevel'] == null ? $default : $model['TankLevel'] ?></td></tr>
                        <tr><th>Service Request :</th><td><?= $model['ServiceRequest'] == 'n' ? "No" : "Yes" ?></td></tr>
                        <tr><th>Notes/Comments :</th><td><?= $model['NotesComents'] == "" ? $default : $model['NotesComents'] ?></td></tr>
                        <tr><th>Pivot Alarm Bypass :</th><td><?= $model['AlarmBypass'] == "n" ? "No" : "Yes" ?></td></tr>
                        <tr><th>Fuel Request :</th><td><?= $model['FuelRequest'] == "n" ? "No" : "Yes" ?></td></tr>
                        <tr><th>Stop and Slot :</th><td><?= $model['StopandSlot'] == "" ? $default : $model['StopandSlot'] ?></td></tr>
                        <tr><th>Scheduled Stop time :</th><td><?= $model['ScheduledStopTime'] == "" ? $default : date('m-d-Y H:i:s', strtotime($model['ScheduledStopTime'])) ?></td></tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div id="message">
            </div>
            <div class="box-title">
                <h3>Additional Information</h3>
            </div>
            <div class="box-content nopadding">

                <table class="table table-striped table-bordered detail-view">
                    <tbody>
                        <tr><th>Pivot Direction :</th><td><?= $direction ?></td></tr>
                        <tr><th>Pivot Speed :</th><td><?= $speed == "" ? $default : $speed ?></td></tr>
                        <tr><th>Pivot Water Rate :</th><td><?= $waterRate ?></td></tr>
                        <!--<tr><th>Incomplete Cycle :</th><td><?= $default ?></td></tr>-->
                        <tr><th>Moving,No pressure :</th><td><?= $moveNoPressure ?></td></tr>
                        <tr><th>No Moving,With pressure :</th><td><?= $noMovePressure ?></td></tr>
                        <tr><th>Pivot Idle Duration :</th><td><?= $idleDuration ?></td></tr>
                        <tr><th>28% need this cycle :</th><td><?= $needCycle ?></td></tr>
                        <tr><th>History Cycles Last :</th><td><?= $default ?></td></tr>
                        <tr><th>Equipment Power :</th><td>
                                <?php
                                $pressureImagePath = "";
                                if ($model['fkDeviceID'] != '')
                                {
                                    if ($moveNoPressure === "Yes" || $noMovePressure === "Yes")
                                    {
                                        $pressureImagePath = "/img/redCircle.png";
                                    }
                                    else
                                    {
                                        if ($pressure != "")
                                        {
                                            if ($pressure == "1")
                                            {
                                                $pressureImagePath = "/img/greenCircle.png";
                                            }
                                            elseif ($pressure == "0")
                                            {
                                                $pressureImagePath = "/img/orangeCircle.png";
                                            }
                                        }
                                        else
                                        {
                                            echo "N/A";
                                        }
                                    }

                                    if ($pressureImagePath != '')
                                    {
                                        ?>
                                        <section class="">
                                            <?= Html::img($imagePath . $pressureImagePath, ['width' => 50, "height" => 50]) ?>
                                        </section>
                                        <?php
                                    }
                                }
                                else
                                {
                                    echo "N/A";
                                }
                                ?>

                            </td></tr>
                        <!--<tr><th>Cell Minutes Used :</th><td><?= $default ?></td></tr>-->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>