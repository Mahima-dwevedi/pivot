<?php

//use Yii;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\widgets\DateTimePicker;

/* @var $this yii\web\View */
/* @var $model app\models\Farm */
/* @var $form yii\widgets\ActiveForm */
?>
<?php // print_r($this->params['id']); die;           ?>
<div class="row-fluid">
    <div class="">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-table"></i><?= Html::encode($this->title) ?></h3>
                <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/site/index'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
            </div>
            <div class="box-content nopadding">
                <?php yii\widgets\Pjax::begin(['id' => 'farm-gird']) ?>
                <?php
                $form = ActiveForm::begin([
                            'id' => 'farm-form',
                            'enableAjaxValidation' => false,
                            'options' => [
                                'class' => 'form-horizontal form-bordered form-validate',
                                ],
                        ]);
                ?>
                
                <?= Html::activeHiddenInput($model, 'type', ['value' => $_GET['type']]) ?>
                <?= Html::activeHiddenInput($model, 'pkEquipmentID', ['value' => $this->params['id']]) ?>
                <?php //echo Html::hiddenField('pkEquipmentID' , 'id', array('id' => 'hiddenInput')); ?>
                <?php //  $form->field($model, 'pkEquipmentID',['errorOptions'=>['class'=>'error']])->hiddenField($model, 'id'); ?>
                <?php // echo $form->hiddenField($model, 'id');  ?>
                <div class="fullwidth">
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'ServiceRequest', ['label' => 'Service Request<span class="required">*</span>', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?php echo $form->field($model, 'ServiceRequest')->dropDownList([ 'n' => 'NO', 'y' => 'Yes'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'AlarmBypass', ['label' => 'Bypass Alarm<span class="required">*</span>', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?php echo $form->field($model, 'AlarmBypass')->dropDownList(['n' => 'NO', 'y' => 'Yes'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'FuelRequest', ['label' => 'Fuel Request<span class="required">*</span>', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?php echo $form->field($model, 'FuelRequest')->dropDownList(['n' => 'NO', 'y' => 'Yes'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'StopandSlot', ['label' => 'Stop Slot Notification', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'StopandSlot', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Degrees'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="fullwidth">
                        <div class="control-group">
                            <?= Html::activeLabel($model, 'ScheduledStopTime', ['label' => 'Predicted Run Time', 'class' => 'control-label']) ?>
                            <div class="controls">
                                <?= $form->field($model, 'ScheduledStopTime', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Hours'])->label(false); ?>
                            </div>
                        </div>
                        <div class="cb"></div>
                    </div>
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'DesiredRate', ['label' => '28% Desired Rate<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'DesiredRate', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => '0 - 20'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'TankLevel', ['label' => '28% Tank Level<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'TankLevel', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => '0 - 3000'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>





                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'RainGaugeReading', ['label' => 'Rain Gauge Reading', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'RainGaugeReading', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Rain Gauge Reading'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'ProbeMoistureAnalysis', ['label' => 'Irrometer', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?php $probeMoisture = ['Not Present' => 'Not Present', '0'=>'0','5'=>'5','10'=>'10','15'=>'15','20'=>'20','25'=>'25','30'=>'30','35'=>'35','40'=>'40','45'=>'45','50'=>'50','55'=>'55','60'=>'60','65'=>'65','70'=>'70','75'=>'75','80'=>'80','85'=>'85','90'=>'90','95'=>'95','100'=>'100'];?>
                            <?= $form->field($model, 'ProbeMoistureAnalysis', ['errorOptions' => ['class' => 'error']])->dropDownList($probeMoisture)->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?php $handmoisture=['No Check'=>'No Check','Very Dry'=>'1: Very Dry','Dry'=>'2: Dry','Getting Dry'=>'3: Getting Dry','Adequate'=>'4: Adequate','Very Wet'=>'5: Very Wet'];?>
                        <?= Html::activeLabel($model, 'HandMoistureAnalysis', ['label' => 'Moisture', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'HandMoistureAnalysis', ['errorOptions' => ['class' => 'error']])->dropDownList($handmoisture,['prompt' => 'Moisture Analysis'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>

                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'NotesComents', ['label' => 'Notes and Comments', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'NotesComents', ['errorOptions' => ['class' => 'error']])->textarea()->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>

                <div class="note "><strong>Note :</strong> <span class="required">*</span> Indicates mandatory fields.</div>

                <div class="form-actions ">  
                    <?= Html::submitButton($model->isNewRecord ? 'Start Pivot' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    <?php // echo Html::a('Start Not Needed',array('/equipmentmeta/create'),array('class'=>'btn')); ?>  
                </div>




                <?php ActiveForm::end(); ?>
                <?php yii\widgets\Pjax::end() ?>
            </div>
        </div>
    </div>
</div>
