<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\ArrayHelper;
use app\models\admin;
use backend\models\farm;
use backend\models\Fieldtechnician;
/* @var $this yii\web\View */
/* @var $model app\models\cms */

$this->title = 'View Farm';
$this->params['breadcrumbs'][] = ['label' => 'Farm', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

//$id=$model->fkCategoryID;
//$modelCombo = Category::find()->select('category_name')->where(['id' => $id])->asArray()->all();;
//$categoryName = $modelCombo[0][category_name];
?>

<div id="margin_mobile" class="page-header">
    <div class="pull-left">
        <h1><?= Html::encode($this->title) ?></h1>
    </div>
</div>

<div class="breadcrumbs">
    <ul>
        <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
        <li><?php // echo Html::a('Manage Farms', ['/farm']); ?><i class="icon-angle-right"></i></li>
        <li><span class="readcrum_without_link">View Farm </span></li>
    </ul>
    <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>


<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><?=$this->title; ?></h3>
               <!-- <a class="btn pull-right" data-toggle="modal" href="<?php  // echo Yii::$app->urlManager->createUrl('/farm'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
        !-->    </div>
            <div class="box-content nopadding">
			<div class="table-responsive">
                <?=
                DetailView::widget([
                    'model' => $model,
                   
                    'attributes' => [
                       [
                            'label' => 'Farm Name',
                            'format' => 'raw',
                            'value' => $model->farmName,
                        ],
                        [
                            'label' => 'Name',
                            'format' => 'raw',
                            'value' => $model->Name,
                        ],
                        [
                            'label' => 'Username',
                            'format' => 'raw',
                            'value' => $model->admin->username,
                        ],
                        [
                            'label' => 'Email Address',
                            'format' => 'raw',
                            'value' => $model->admin->email,
                        ],
                        [
                            'label' => 'Contact Detail',
                            'format' => 'raw',
                            'value' => $model->admin->phone,
                        ],
                        [
                            'label' => 'Address1',
                            'format' => 'raw',
                            'value' => $model->farmAddress1,
                        ],
                        [
                            'label' => 'Address2',
                            'format' => 'raw',
                            'value' => $model->farmAddress2,
                        ],
                        
                        [ 'attribute'=>'farmLicenseStartDate',
                            'format' => 'raw',
                             'value' => date("m-d-Y",  strtotime($model->farmLicenseStartDate)),
                        ],
                        [
                            'label' => 'License Expire-Date',
                            'format' => 'raw',
                             'value' => date("m-d-Y",  strtotime($model->farmLicenseExpireDate)),
                        ],
                        [
                            'label' => 'Status',
                            'format' => 'raw',
                            'value' => $model->farmStatus,
                        ],
                        
                      ],
                ])
                ?>
			</div>
            </div>

        </div>
    </div>
</div>

