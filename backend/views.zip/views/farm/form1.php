<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;
/* @var $this yii\web\View */
/* @var $model app\models\Farm */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="row-fluid">
   <div class="span12">
      <div class="box box-color box-bordered">
	 <div class="box-title">
	      <h3><i class="icon-table"></i><?= Html::encode($this->title) ?></h3>
               <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/site/index');?>"><i class="icon-circle-arrow-left"></i> Back</a>
	 </div>
         <div class="box-content nopadding manageaccount">
            
            <?php $form = ActiveForm::begin([
	    'id' => 'farm-form',
            'enableAjaxValidation'=>false,
            'action' => '../site/createaccount',
                        
	    'options' => [
	                'class' => 'form-horizontal form-bordered form-validate',
	                'enctype' => 'multipart/form-data'
	                ],
            
            ]); ?>
                   <div class="fullwidth">
                    <div class="control-group">
                       
                        <?= Html::activeLabel($model, 'radio', ['label'=>'Add Account<span class="required">*</span>', 'class'=>'control-label']) ?>
                        <div class="controls">
                            <?php if(Yii::$app->user->identity->Adminlevel == '0'){ ?>
                            <div class="span6" style=float:left;>
                            <?= $form->field($model, 'radio')->radioList(array('1'=>'Farm Admin','2'=>'Field technician'),array())->label(false);?>
                            </div>
                            <?php }else {?>
                            <div class="span6" style=float:left;>
                            <?= $form->field($model, 'radio')->radioList(array('2'=>'Field technician'),array())->label(false);?>
                            </div>
                            <?php }?>
                    </div> </div>
                    <div class="cb"></div>
                </div>
	    
           <div class="form-actions span11">
	      <?= Html::submitButton($model->isNewRecord ? 'Add Account' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
               
	    </div>
	    <?php ActiveForm::end(); ?>
        
	 </div>
      </div>
   </div>
</div>
