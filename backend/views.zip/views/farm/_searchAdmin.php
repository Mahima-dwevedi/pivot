<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\web\JsExpression;
use yii\jui\AutoComplete;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\searchusers */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3>Search Account</h3>
            </div>
            <div class="box-content nopadding">


                <?php
        

                $form = ActiveForm::begin([
                             'action' => ['manage'],
                            'method' => 'get',
                            'id' => '_search-form',
                            'options' => ['class' => 'form-horizontal form-bordered']
                        ]);
                ?>

                <div class="row-fluid">
                    <div class="wide form">
                        <div class="span6">
                            <div class="control-group">
                                <?= Html::activeLabel($model, 'Name', ['label' => 'Farm/Technician Name', 'class' => 'control-label']) ?>

                                <div class="controls">

                                    <?php echo $form->field($model, 'Name')->textInput()->label(false); ?>
                                </div>
                            </div>
                        </div> 
                        <?php 
                        if(Yii::$app->user->identity->Adminlevel == '0') {?>
                        <div class="span6">
                            <div class="control-group">
                                <?= Html::activeLabel($model, 'user_type', ['label' => 'User Type', 'class' => 'control-label']) ?>

                                <div class="controls">

                                    <?php echo $form->field($model, 'user_type')->dropDownList(['farm-admin'=>'Farm-Admin','field-admin'=>'Field Technician'],['prompt'=>'Select User Type'])->label(false); ?>
                                </div>
                            </div>
                        </div> 
                        
                        <?php }?>
                   
                        <div class="row-fluid">
                            <div class="row-fluid">
                                <div class="form-actions span11  search">
                                    <div class="form-group">
                                        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
                                        <?= Html::a('Reset', ['farm/manage'], ['id' => 'resetVal', 'class' => 'btn btn-default']) ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                        ActiveForm::end();
                       
                        ?>

                    </div><!-- search-form -->
                </div>
            </div>
        </div>
    </div>


</div>

