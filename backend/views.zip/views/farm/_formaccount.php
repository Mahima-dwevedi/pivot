<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;

/* @var $this yii\web\View */
/* @var $model app\models\Farm */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="row-fluid">
    <div class="span12">
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-table"></i><?= Html::encode($this->title) ?></h3>
                <a class="btn pull-right" data-toggle="modal" href="<?php echo Yii::$app->urlManager->createUrl('/farm/manage'); ?>"><i class="icon-circle-arrow-left"></i> Back</a>
            </div>
            <div class="box-content nopadding">
                <?php yii\widgets\Pjax::begin(['id' => 'farm-gird']) ?>
                <?php
                $form = ActiveForm::begin([
                            'id' => 'farm-form',
                            'enableAjaxValidation' => false,
                            'options' => [
                                'class' => 'form-horizontal form-bordered form-validate',
                                ],
                        ]);
                ?>

                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'farmName', ['label' => 'Farm Admin Name<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'farmName', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Farm Admin Name'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>


                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($modelAdmin, 'username', ['label' => 'Username <span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($modelAdmin, 'username', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Username'])->label(false); ?>
                        </div>

                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($modelAdmin, 'password', ['label' => 'Password <span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($modelAdmin, 'password', ['errorOptions' => ['class' => 'error']])->passwordInput(['placeholder' => 'Password'])->label(false); ?>
                        </div>

                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'farmAddress1', ['label' => 'Address ', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'farmAddress1', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Address1'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'farmAddress2', ['label' => '', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'farmAddress2', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Address2'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($modelAdmin, 'email', ['label' => 'Email Address<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($modelAdmin, 'email', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Email Address'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($modelAdmin, 'confirm_email', ['label' => 'Confirm Email Address<span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($modelAdmin, 'confirm_email', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Email Address'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($modelAdmin, 'phone', ['label' => 'Cell Phone Number <span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($modelAdmin, 'phone', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'ie. 234-234-2345','maxlength'=>'12'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($modelAdmin, 'phone_provider', ['label' => 'Cell Phone Provider <span class="required">*</span>', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($modelAdmin, 'phone_provider', ['errorOptions' => ['class' => 'error']])->textInput(['placeholder' => 'Cell Phone Provider'])->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>
                <div class="fullwidth">
                    <div class="control-group">
                        <?= Html::activeLabel($model, 'farmNotificationStatus', ['label' => 'Comment', 'class' => 'control-label']) ?>
                        <div class="controls">
                            <?= $form->field($model, 'farmNotificationStatus', ['errorOptions' => ['class' => 'error']])->textArea()->label(false); ?>
                        </div>
                    </div>
                    <div class="cb"></div>
                </div>

                <div class="note "><strong>Note :</strong> <span class="required">*</span> Indicates mandatory fields.</div>

                <div class="form-actions ">
                    <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update Farm', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    <?php echo Html::a('Cancel', array('/farm/manage'), array('class' => 'btn')); ?>
                </div>
                <?php ActiveForm::end(); ?>
                <?php yii\widgets\Pjax::end() ?>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
 $(function(){
    $("#admin-phone").mask("999-999-9999");
 });
</script>