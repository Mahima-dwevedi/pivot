<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchBank */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Manage Farms';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="pull-right margin_top20 mobile_margin">
    <?= Html::a('Add New Farm', ['create'], ['class' => 'btn btn-success']) ?>
    
</div>

<div class="user-index">

    <div class="page-header">
        <div class="pull-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>          
    </div>
    <di v class="breadcrumbs">
        <ul>
            <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
            <li><span class="readcrum_without_link">Manage Farms </span></li>
        </ul>
        <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
    </div>
 <div class="row-fluid">
         <?php \yii\widgets\Pjax::begin(['id' => 'farm-grid']); ?>
        <div class="breadcrumbs" id="message">
    </div>
        <div class="breadcrumbs" id="breadcrumbs-msg">

            <?php if ((Yii::$app->session->hasFlash('create')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active'))) { ?>
                <ul>
                    <?php
                    if (Yii::$app->session->getFlash('create')) {
                        echo '<li><span class="readcrum_without_link_success">' . ADD_FARM_SUCCESS . '</li>';
                    } else if (Yii::$app->session->getFlash('update')) {
                        echo '<li><span class="readcrum_without_link_success">' . EDIT_FARM_SUCCESS . '</li>';
                    } else if (Yii::$app->session->getFlash('delete')) {
                        echo '<li><span class="readcrum_without_link_success">' . DEACTIVATE_FARM_SUCCESS . '</li>';
                    } else if (Yii::$app->session->getFlash('error')) {
                        echo '<li><span class="readcrum_without_link_success">' . ERROR_FARM_SUCCESS . '</li>';
                    } else if (Yii::$app->session->getFlash('active')) {
                        echo '<li><span class="readcrum_without_link_success">' . ACTIVATE_FARM_ACCOUNT . '</li>';
                    }
                     else if (Yii::$app->session->getFlash('createfield')) {
                        echo '<li><span class="readcrum_without_link_success">' . ADD_FIELDTECH_ACCOUNT . '</li>';
                    }
                    ?>						
                </ul>
            <?php }
            ?>
        </div>
    <div class="search-form">
        <?php echo $this->render('_search', ['model' => $searchModel]); ?>
    </div><!-- search-form -->
   

        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-reorder"></i> All Farm Details</h3>
                <!--<a class="btn pull-right" data-toggle="modal" href="#" id = "viewAll">View All</a>-->
            </div>
            <div class="clear"></div>

            <div class="box-content nopadding table-responsive">
                <?php \yii\widgets\Pjax::begin(['id' => 'farm-grid-pjax']); ?>   
                <form action="" name='farm-grid-list-form' id='farm-grid-list-form'>

                    <?=
                    GridView::widget([
                        'dataProvider' => $dataProvider,
                       'id' => 'farm-grid',
                        'columns' => [
                            [
                                'name' => 'farmID',
                                'class' => 'yii\grid\CheckboxColumn'
                            ],
                            ['class' => 'yii\grid\SerialColumn'],
                            [
                                'attribute' => 'farmName',
                                 'label' => 'Farm Name',
                                'value' => function ($data) {
                                    return $data->farmName; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'username',
                                 'label' => 'User Name',
                                'value' => function ($data) {
                                    return $data->admin->username; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'Email Address',
                                'value' => function ($data) {
                                    return $data->admin->email; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'phone',
                                   'label' => 'Contact Details',
                                'value' => function ($data) {
                                    return $data->admin->phone; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'farmAddDate',
                                   'label' => 'Created Date',
                                'format' => 'raw',
                                'value' => function ($data) {
                                    return date("m-d-Y", strtotime($data->farmAddDate));  // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'farmLicenseStartDate',
                                'label' => 'License Start Date',
                                'format' => 'raw',
                                'value' => function ($data) {
                                    return date("m-d-Y", strtotime($data->farmLicenseStartDate)); // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'farmLicenseExpireDate',
                                'label' => 'License Expire Date',
                                'format' => 'raw',
                                'value' => function ($data) {
                                    return date("m-d-Y", strtotime($data->farmLicenseExpireDate)); // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'farmStatus',
                                'label' => '  Status ',
                                'format' => 'raw',
                                'contentOptions'=>['style'=>'width: 100px;'],
                                'value' => function ($data) {
                                    return $data->farmStatus; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'header' => 'Action',
                                'class' => 'yii\grid\ActionColumn',
                                'template' => '{view} {update} {deactivate} {activate} {delete}',
                                'buttons' => [
                                    'deactivate' => function ($url, $model) {
                                        return Html::a('<span class="glyphicon icon-ban-circle my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'deactivate'), 'data-pjax' => '0', 'data-confirm' => 'Are you sure you want to deactivate this account?',
                                        ]);
                                    },
                                    'activate' => function ($url, $model) {
                                        return Html::a('<span class="glyphicon icon-ok my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'activate'), 'data-pjax' => '0', 'data-confirm' => 'Are you sure you want to activate this account?',
                                        ]);
                                    },
                                    'view' => function ($url, $model) {
                                        return Html::a('<span class="glyphicon icon-eye-open my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'view'), 'data-pjax' => '0',
                                        ]);
                                    },
                                    'update' => function ($url, $model) {
                                        return Html::a('<span class="glyphicon icon-pencil my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'update'), 'data-pjax' => '0',
                                        ]);
                                    },
                                ],
                                'urlCreator' => function ($action, $model, $key, $index) {
                                    if ($action === 'activate') {
                                        $url = Yii::$app->urlManager->createUrl(['farm/activate', 'id' => $model->farmID]);
                                        //$url ='../../../view?slug='.$model->slug;
                                        return $url;
                                    }
                                    if ($action === 'deactivate') {
                                        $url = Yii::$app->urlManager->createUrl(['farm/deactivate', 'id' => $model->farmID]); 
                                        //$url ='../../../view?slug='.$model->slug;
                                        return $url;
                                    }
                                    if ($action === 'view') {
                                        $url = Yii::$app->urlManager->createUrl(['farm/view', 'id' => $model->farmID]);
                                        return $url;
                                    }
                                    if ($action === 'update') {
                                        $url = Yii::$app->urlManager->createUrl(['farm/update', 'id' => $model->farmID]);

                                        return $url;
                                    }
                                    if ($action === 'delete') {
                                        $url = Yii::$app->urlManager->createUrl(['farm/delete', 'id' => $model->farmID]);

                                        return $url;
                                    }
                                }
                            ],
                        ],
                    ]);
                    ?>
         <div class="control-group">
                  <div class="controls faqstatusDropdown">
                       <?= Html:: dropDownList('farmStatus','',[ 'activate' => 'Active', 'deactivate' => 'Deactive', ], ['prompt' => '--Choose Action--','onchange'=> 'farmMultipleAction(this.value)','id'=>'farmStatus']) ?>
                    </div>
            </div>
                </form>
                <?= Html::endForm() ?>
                    <?php \yii\widgets\Pjax::end(); ?>
                    <?php echo common\components\PaginationField::widget(); ?>

            </div>
                
        </div>
    </div>
<script>
    
    function farmMultipleAction(action){
        var checked_num = $('input[name="farmID[]"]:checked').length;
      
        if (!checked_num) { 
            alert('Please select atleast one.');
            $.pjax.reload({container:'#farm-grid-pjax'});
            $(document).on('pjax:complete', function(){
                $("#farmStatus").select2();
            });
        }
        else
        { 
     if(action=='activate' || action=='deactivate'){      
 
    if ($('#farmStatus').val()=='Select') {
                alert('Please Select valid option');
            }
            else
            {
                if(confirm("Are you sure you want to perform this action?")){      
                var data=$("#farm-grid-list-form").serialize();
                $.ajax({
                    type: 'POST',
                    url: './changestatus',
                    data:data,
                   
                    success:function(data){  
                        if(data)
                        {      
                            var statusMsg = "";
                                statusMsg = 'Farm status has been Update successfully.';
                                $('#message').html("<div class='breadcrumbs' id='breadcrumbs-msg'><ul><li><span class='readcrum_without_link_success'>"+statusMsg+"</span></li></ul></div>");
                                $('#breadcrumbs-msg').fadeOut(5000);
                                $.pjax.reload({container:'#farm-grid-pjax'});
                                $(document).on('pjax:complete', function(){
                              
                              });
                                statusMsg = '';
                        } 
                    },error: function(data) { // if error occured
                        alert("Error occured.Please try again.");
                        $.pjax.reload({container:'#farm-grid-pjax'});
                        $(document).on('pjax:complete', function(){
                            $("#farmStatus").select2();
                        });
                    },
                    dataType:'html'
                });
			 }  else {
                    $('input[type="checkbox"]').prop('checked', false);
                    $("#farmStatus").select2("val", "Select");
                }           
            }
        } 
    }
    }
    
    $('.search-button').click(function(){
        $('.search-form').toggle();
        return false;
    });
</script>


