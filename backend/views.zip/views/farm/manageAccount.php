<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchBank */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Manage Accounts';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="user-index">

    <div class="page-header">
        <div class="pull-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>          
    </div>
    <di v class="breadcrumbs">
        <ul>
            <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
            <li><span class="readcrum_without_link">Manage Accounts</span></li>
        </ul>
        <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
</div>
<div class="row-fluid">

    <div class="breadcrumbs" id="message">
    </div>
    <div class="breadcrumbs" id="breadcrumbs-msg">

        <?php if ((Yii::$app->session->hasFlash('create')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active')) || (Yii::$app->session->hasFlash('createfield')))
        { ?>
            <ul>
                <?php
                if (Yii::$app->session->getFlash('create'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . ADD_FARM_SUCCESS . '</li>';
                }
                else if (Yii::$app->session->getFlash('update'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . EDIT_FARM_SUCCESS . '</li>';
                }
                else if (Yii::$app->session->getFlash('delete'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . DEACTIVATE_FARM_SUCCESS . '</li>';
                }
                else if (Yii::$app->session->getFlash('error'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . ERROR_FARM_SUCCESS . '</li>';
                }
                else if (Yii::$app->session->getFlash('active'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . ACTIVATE_FARM_ACCOUNT . '</li>';
                }
                else if (Yii::$app->session->getFlash('createfield'))
                {
                    echo '<li><span class="readcrum_without_link_success">' . ADD_FIELDTECH_ACCOUNT . '</li>';
                }
                ?>						
            </ul>
<?php }
?>
    </div>
    <div class="search-form">
<?php echo $this->render('form1', ['model' => $model]) ?>
    </div>
    <div class="search-form">
            <?php echo $this->render('_searchAdmin', ['model' => $searchModel]); ?>
    </div><!-- search-form -->


    <div class="box box-color box-bordered">

        <div class="box-title">
            <h3><i class="icon-reorder"></i>Account Details</h3>
            <!--<a class="btn pull-right" data-toggle="modal" href="#" id = "viewAll">View All</a>-->
        </div>
        <div class="clear"></div>

        <div class="box-content nopadding">
                    <?php \yii\widgets\Pjax::begin(); ?>
            <form action="" name='farm-grid-list-form' id='farm-grid-list-form'>
                <div class="table-responsive">
                    <?=
                    GridView::widget([
                        'dataProvider' => $dataProvider,
                        'id' => 'farm-grid',
                        'columns' => [
//                            [
//                                'name' => 'farmID',
//                                'class' => 'yii\grid\CheckboxColumn'
//                            ],
                            ['class' => 'yii\grid\SerialColumn'],
                            [
                                'attribute' => 'Name',
                                'label' => 'Farm/Technician Name',
                                'value' => function ($data)
                                {
                                    return $data->Name; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'username',
                                'label' => 'User Name',
                                'value' => function ($data)
                                {
                                    return $data->username; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'email',
                                'label' => 'Email Address',
                                'value' => function ($data)
                                {
                                    return $data->email; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'phone',
                                'label' => 'Cell Phone Number',
                                'value' => function ($data)
                                {
                                    return $data->phone; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'user_type',
                                'label' => 'User Type',
                                'value' => function ($data)
                                {
                                    return ($data->user_type == 'farm-admin' ? 'Farm Admin' : 'Technician'); // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'created_at',
                                'label' => 'Created Date',
                                'value' => function ($data)
                                {
                                    return Date('m-d-Y', strtotime($data->created_at)); // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'attribute' => 'status',
                                'label' => 'status',
                                'value' => function ($data)
                                {
                                    return Yii::$app->params['arrAdminStatus'][$data->status]; // $data['name'] for array data, e.g. using SqlDataProvider.
                                },
                            ],
                            [
                                'header' => 'Action',
                                'class' => 'yii\grid\ActionColumn',
                                'template' => '{viewfieldtech}{view}{deactivate}{activate} {updatefieldtech} {update}',
                                'buttons' => [
                                    'deactivate' => function ($url, $model)
                                    {
                                        return Html::a('<span class="glyphicon icon-ban-circle my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'deactivate'), 'data-pjax' => '0', 'data-confirm' => 'Are you sure you want to deactivate this account?',
                                                ]);
                                    },
                                    'activate' => function ($url, $model)
                                    {
                                        return Html::a('<span class="glyphicon icon-ok my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'activate'), 'data-pjax' => '0', 'data-confirm' => 'Are you sure you want to activate this account?',
                                                ]);
                                    },
                                    'view' => function ($url, $model)
                                    {
                                        return $model->user_type == 'farm-admin' ? Html::a('<span class="glyphicon icon-eye-open my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'view'), 'data-pjax' => '0',
                                                ]) : '';
                                    },
                                    'viewfieldtech' => function ($url, $model)
                                    {
                                        return $model->user_type == 'field-admin' ? Html::a('<span class="glyphicon icon-eye-open my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'view'), 'data-pjax' => '0',
                                                ]) : '';
                                    },
                                    'updatefieldtech' => function ($url, $model)
                                    {
                                        return $model->user_type == 'field-admin' ? Html::a('<span class="glyphicon icon-pencil my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'update'), 'data-pjax' => '0',
                                                ]) : '';
                                    },
                                    'update' => function ($url, $model)
                                    {
                                        return $model->user_type == 'farm-admin' ? Html::a('<span class="glyphicon icon-pencil my_font_icon"></span>', $url, [
                                                    'title' => Yii::t('app', 'update'), 'data-pjax' => '0',
                                                ]) : '';
                                    },
                                ],
                                'urlCreator' => function ($action, $model, $key, $index)
                                {
                                    if ($action === 'activate')
                                    {
                                        $url = Yii::$app->urlManager->createUrl(['site/activate', 'id' => $model->pkAdminID]);
                                        //$url ='../../../view?slug='.$model->slug;
                                        return $url;
                                    }
                                    if ($action === 'deactivate')
                                    {
                                        $url = Yii::$app->urlManager->createUrl(['site/deactivate', 'id' => $model->pkAdminID]);
                                        //$url ='../../../view?slug='.$model->slug;
                                        return $url;
                                    }
                                    if ($action === 'view')
                                    {
                                        $url = Yii::$app->urlManager->createUrl(['farm/view', 'id' => $model->pkAdminID]);
                                        return $url;
                                    }
                                    if ($action === 'viewfieldtech')
                                    {
                                        $url = Yii::$app->urlManager->createUrl(['fieldtechnician/view', 'id' => $model->pkAdminID]);
                                        return $url;
                                    }
                                    if ($action === 'updatefieldtech')
                                    {
                                        $url = Yii::$app->urlManager->createUrl(['fieldtechnician/update', 'id' => $model->pkAdminID]);
                                        return $url;
                                    }
                                    if ($action === 'update')
                                    {
                                        $url = Yii::$app->urlManager->createUrl(['farm/update-farm-admin', 'id' => $model->pkAdminID]);

                                        return $url;
                                    }
                                }
                        ],
                            ],
                    ]);
                    ?>
                </div>


        </div>

    </div>
</div>
<script>

    function farmMultipleAction(action) {
        var checked_num = $('input[name="farmID[]"]:checked').length;

        if (!checked_num) {
            alert('Please select atleast one.');
            $.pjax.reload({container: '#farm-grid'});
            $(document).on('pjax:complete', function() {
                $("#farmStatus").select2();
            });
        }
        else
        {
            if (action == 'activate' || action == 'deactivate') {

                if ($('#farmStatus').val() == 'Select') {
                    alert('Please Select valid option');
                }
                else
                {
                    if (confirm("Are you sure you want to perform this action?")) {
                        var data = $("#farm-grid-list-form").serialize();
                        $.ajax({
                            type: 'POST',
                            url: './changestatus',
                            data: data,
                            success: function(data) {
                                if (data)
                                {
                                    var statusMsg = "";
                                    statusMsg = 'Farm status has been Update successfully.';
                                    $('#message').html("<div class='breadcrumbs' id='breadcrumbs-msg'><ul><li><span class='readcrum_without_link_success'>" + statusMsg + "</span></li></ul></div>");
                                    $('#breadcrumbs-msg').fadeOut(3000);
                                    //$.pjax.reload({container:'#farm-grid'});
                                    $(document).on('pjax:complete', function() {
                                        //     $("#faqStatus").select2();
                                    });
                                    statusMsg = '';
                                }
                            }, error: function(data) { // if error occured
                                alert("Error occured.Please try again.");
                                $.pjax.reload({container: '#farm-grid'});
                                $(document).on('pjax:complete', function() {
                                    $("#farmStatus").select2();
                                });
                            },
                            dataType: 'html'
                        });
                    } else {
                        $('input[type="checkbox"]').prop('checked', false);
                        $("#farmStatus").select2("val", "Select");
                    }
                }
            }
        }
    }

    $('.search-button').click(function() {
        $('.search-form').toggle();
        return false;
    });
</script>


