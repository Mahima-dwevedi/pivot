<?php

use yii\helpers\Html;
use yii\grid\GridView;

$baseUrl = Yii::$app->getUrlManager()->getBaseUrl();
$imagePath = Yii::$app->request->BaseUrl;
$varID = isset($_GET['ID']) ? ($_GET['ID']) : 0;
$this->title = 'Field Map View';
$this->params['breadcrumbs'][] = $this->title;

?>

<div class="user-index">

    <div class="page-header">
        <div class="pull-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>          
    </div>
</div>
<?php //echo '<pre>'; print_r($allEquipment); ?>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>	
<?php
/* @var $this yii\web\View */
?>
<!--<h1>list-view/index</h1>-->
<section class="">
            <section class="map_outer_container">
        

            <section class="eqp" id="eqpid"></section>
            <?php
            if (count($allEquipment) > 0)
            {
                ?>
                <section class = "location_on_map" id="map">

                    <script type="text/javascript">
                        var type="&type="+"<?= Yii::$app->controller->id ?>";
                        $(document).ready(function() {

                            var ma = <?php echo json_encode($allEquipment) ?>;
                            showMapMerchantPublicPage(ma);
                        });
                    </script>

                </section>
            <?php } ?>  

        <section style="padding-left:30px;padding-top:30px;float:left;">
            <div><img src="<?= $imagePath ?>/img/grayCircle.png" height="25" width="25"><span style="font-size:20px;color:black;margin-left:10px;">Pivot Off or Not Reporting</span></div>
            <div><img src="<?= $imagePath ?>/img/greenCircle.png" height="25" width="25"><span style="font-size:20px;color:black;margin-left:10px;">Water Pressure + Movement&#42;</span></div>
            <div><img src="<?= $imagePath ?>/img/redCircle.png" height="25" width="25"><span style="font-size:20px;color:black;margin-left:10px;">Pivot Issue</span><div>
            <div>&nbsp;</div>
            <div><p style="font-size:20px;color:black;margin-left:10px;">&#42;Movement based on position 2 HRs ago<BR>&#42;Movement assumed for first 2 HRs</p></div>
        </section>          
        </section>
    <section class="col-md-12 list_view_main_wrapper">
        <section class="col-md-3 view_left_panel map_view_panel"><!--Left Panel-->
            <a href="map-view"><button type="button" class="col-md-12 view_fields <?php echo  ($varID == 0 ) ? 'list_active' : '' ?>">All</button></a>
            <?php
            foreach ($model as $fieldvalue)
            {
                ?>
                <a href="?ID=<?php echo $fieldvalue['fieldID']; ?>">
                    <button type="button" class="col-md-12 view_fields <?= ($fieldvalue['fieldID'] == $varID ) ? 'list_active' : '' ?>">
                        <?php echo $fieldvalue['fieldName'] ?>
                    </button></a>
                <?php
            }
            ?> 
        </section>

   </section>
</section>



<script type ="text/javascript">
    function showMapMerchantPublicPage($arrData) {
        var circleColor = '';
        $.each($arrData, function(key, val) {
            if (key == 0) {
                defaultLat = val.Latitude;
                defaultLon = val.Longitude;
            }
            return false;
        });
    //locating the point on the radius
    /*
     * 
     * @returns {Number|Number.prototype}
     */
    Number.prototype.toRad = function() {
        return this * Math.PI / 180;
     }

     Number.prototype.toDeg = function() {
        return this * 180 / Math.PI;
     }

    google.maps.LatLng.prototype.destinationPoint = function(brng, dist) {
       dist = dist / 6371;  
       brng = brng.toRad();  

       var lat1 = this.lat().toRad(), lon1 = this.lng().toRad();

       var lat2 = Math.asin(Math.sin(lat1) * Math.cos(dist) + 
                            Math.cos(lat1) * Math.sin(dist) * Math.cos(brng));

       var lon2 = lon1 + Math.atan2(Math.sin(brng) * Math.sin(dist) *
                                    Math.cos(lat1), 
                                    Math.cos(dist) - Math.sin(lat1) *
                                    Math.sin(lat2));

       if (isNaN(lat2) || isNaN(lon2)) return null;

       return new google.maps.LatLng(lat2.toDeg(), lon2.toDeg());
    }
    /*
     * END
     */
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 13,
            center: new google.maps.LatLng(defaultLat, defaultLon),
            mapTypeId: google.maps.MapTypeId.HYBRID,
            minZoom: 3
        });

        var marker, i;
        var baseUrl = "<?php echo $baseUrl;?>";

        $.each($arrData, function(key, val) {

            var lat_lng = new google.maps.LatLng(val.Latitude, val.Longitude);

            var markerIcon = new google.maps.Marker({
                position: new google.maps.LatLng(val.Latitude, val.Longitude),
                icon: baseUrl + '/img/img'+val.overallColor+".png",
                map: map
            });
            //console.log(markerIcon);

            var northTop = parseFloat("0.0001") + parseFloat(val.Latitude);
            var northBottom = parseFloat(val.Latitude) - parseFloat("0.0030");

            var southTop = parseFloat(val.Longitude) - parseFloat("0.0050");
            var southBottom = parseFloat(val.Longitude) + parseFloat("0.0050");
            
            circleColor = val.overallColor;
            //console.log(circleColor);

            if (parseInt(val.EquipmentType) == '1' || parseInt(val.EquipmentType) == '2')
            {
                
                marker = new google.maps.Rectangle({
                    strokeColor: circleColor,
                    strokeOpacity: 0.8,
                    strokeWeight: 2,
                    fillColor: circleColor,
                    fillOpacity: 0.45,
                    map: map,
                    bounds: new google.maps.LatLngBounds(
                    new google.maps.LatLng(northTop, southTop),
                    new google.maps.LatLng(northBottom, southBottom))
                });
            }
            else
            {
                marker = new google.maps.Circle({
                    map: map,
                    radius: parseInt(val.EqpLength * 25 / 100),
                    center: lat_lng,
                    strokeColor: circleColor,
                    strokeOpacity: 0.8,
                    strokeWeight: 2,
                    fillColor: circleColor,
                    fillOpacity: 0.45                 
                });
                
                var rad = parseInt(val.position) ? parseInt(val.position) : 0;
                //rad = 45;
                //if(rad){
                /*
                 * Radius line
                 */
                var pointA = new google.maps.LatLng(lat_lng.lat(), lat_lng.lng()); 
                var radiusInKm = parseInt(val.EqpLength * 25 / 100)/1000;
                var pointB = pointA.destinationPoint(rad, radiusInKm);
                //console.log(pointB);
                var flightPlanCoordinates = [
                    {
                        lat : lat_lng.lat(),
                        lng : lat_lng.lng()
                    },
                    {
                        lat : pointB.lat(),
                        lng : pointB.lng()
                    },
                  ];
                  if(val.position > 0)
                  {
                    rotation = 0;
                  }
                  if(val.position < 0)
                  {
                    rotation = 180;
                  }
                  if(val.position == 0)
                  {
                    rotation = 0;
                  }

                  var lineSymbol = {
                    path: "M0,0 L0,6 L9,3 z",
                    rotation: rotation,
                    scale: 1
                  };
                  //console.log(flightPlanCoordinates);
                  var flightPath = new google.maps.Polyline({
                    path: flightPlanCoordinates,
                    geodesic: true,
                    strokeColor: '#000000',
                    strokeOpacity: 1.0,
                    strokeWeight: 2,
                    icons: [{
                        icon: lineSymbol,
                        offset: '95%'
                      }],
                  });

                  flightPath.setMap(map);
                  /*
                   * End
                   */
                    
                //}
            }    

            google.maps.event.addListener(markerIcon, 'click', (function(marker, i) {
                return function() {
                    var noData = "NA";
                    var EquipmentName = (val.EquipmentName == '') ? noData : val.EquipmentName;
                    var irrigationName = (val.irrigationName == null) ? noData : val.irrigationName;
                    

                    var EquipmentLastAction = '';

                    if (val.PivotStopAction == "") {
                        var EquipmentLastAction = noData;
                    } else {
                        var EquipmentLastAction = (val.PivotStopAction == '1') ? 'Start @' + new moment(val.updateDate).format("MM-DD-YYYY h:m:s") : 'Stop @' + new moment(val.updateDate).format("MM-DD-YYYY h:m:s");
                    }

                    if (val.pressure == "1" && val.movementColor == "Green") {
                        var pressureImage = '<img src="<?= $imagePath ?>/img/greenCircle.png" height="15" width="15">';
                    } 
                    else if ((val.pressure == "0" && val.movementColor == "Red") || val.movementColor == "Gray") {                       
                        var pressureImage = '<img src="<?= $imagePath ?>/img/grayCircle.png" height="15" width="15">';
                    } 
                    else {
                        var pressureImage = '<img src="<?= $imagePath ?>/img/redCircle.png" height="15" width="15">';
                    }   

                    if (val.movementColor == "Green") {
                        var movementImage = '<img src="<?= $imagePath ?>/img/greenCircle.png" height="15" width="15">';
                    } 
                    else if (val.movementColor == "Gray") {                       
                        var movementImage = '<img src="<?= $imagePath ?>/img/grayCircle.png" height="15" width="15">';
                    } 
                    else {
                        var movementImage = '<img src="<?= $imagePath ?>/img/redCircle.png" height="15" width="15">';
                    }                   

                    htms = '<section class="col-md-12 map_main_container">';
                    htms += '<img src="<?= $imagePath ?>/img/cross-icon.png" height="20" width="20" class="close-abs">';
                    htms += '<section class="pivot_detail map_main_wrapper">';                
                    htms += '<h5> Equipment: </h5><span class="pivot_name">' + EquipmentName + '</span>';
                    htms += '<h5> Position: </h5><span class="pivot_degree">' + val.position + ' &deg;</span>';
                    htms += '<h5> Pressure: </h5><span class="buttonImages">' + pressureImage + '</span>';
                    htms += '<h5> Movement: </h5><span class="buttonImages">' + movementImage + '</span>';
                    htms += '<h5> ' + val.motionReasonNotes + ' </h5><span>' + val.motionReasonText + '</span>';
                    htms += '</section>';
                    htms += '<section class="buttons-abs">';
                    //htms += '<h5> ' + val.motionReasonNotes + ' </h5><span>' + val.motionReasonText + '</span>';
                    //htms += '<h5> Latitude / Longitude: </h5><span class="lat_long">' + val.Latitude + ' / ' + val.Longitude + '</span>';
                    
                    //htms += '<div class="map_buttons pull-right"> ';

                    if (val.fkDeviceID != '') {

                        if (val.EqpStatus == '1') {
                            htms += '<a data-confirm="Are you sure you want to do STOP this equipment?" href="javascript:stopEqup(' + val.pkEquipmentID + ')"> <button type="button" class="pivot_stop_btn"> Stop </button></a>';
                        } else {
                            htms += '<a data-confirm="Are you sure you want to do START this equipment?" href="equipmentmeta/create?id=' + val.pkEquipmentID +type+ '"> <button type="button" class="pivot_start_btn"> Start Pivot </button></a>';
                        }
                    }

                    htms += '<a href="pivot-summary/index?id=' + val.pkEquipmentID + '"> <button type="button" class="pivot_start_btn"> Summary </button></a>';
                    htms += '</section>';
                    htms += '</section>';
                    $('#eqpid').html(htms);
                }
            })(marker, i));
            
            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                return function() {
                    var noData = "NA";
                    var EquipmentName = (val.EquipmentName == '') ? noData : val.EquipmentName;
                    var irrigationName = (val.irrigationName == null) ? noData : val.irrigationName;
					

                    var EquipmentLastAction = '';

                    if (val.PivotStopAction == "") {
                        var EquipmentLastAction = noData;
                    } else {
                        var EquipmentLastAction = (val.PivotStopAction == '1') ? 'Start @' + new moment(val.updateDate).format("MM-DD-YYYY h:m:s") : 'Stop @' + new moment(val.updateDate).format("MM-DD-YYYY h:m:s");
                    }

					if (val.pressure == "1" && val.movementColor == "Green") {
                        var pressureImage = '<img src="<?= $imagePath ?>/img/greenCircle.png" height="15" width="15">';
                    } 
					else if ((val.pressure == "0" && val.movementColor == "Red") || val.movementColor == "Gray") {                       
                        var pressureImage = '<img src="<?= $imagePath ?>/img/grayCircle.png" height="15" width="15">';
                    } 
					else {
						var pressureImage = '<img src="<?= $imagePath ?>/img/redCircle.png" height="15" width="15">';
					}	

					if (val.movementColor == "Green") {
                        var movementImage = '<img src="<?= $imagePath ?>/img/greenCircle.png" height="15" width="15">';
                    } 
					else if (val.movementColor == "Gray") {                       
                        var movementImage = '<img src="<?= $imagePath ?>/img/grayCircle.png" height="15" width="15">';
                    } 
					else {
						var movementImage = '<img src="<?= $imagePath ?>/img/redCircle.png" height="15" width="15">';
					}					

                    htms = '<section class="col-md-12 map_main_container">';
                    htms += '<img src="<?= $imagePath ?>/img/cross-icon.png" height="20" width="20" class="close-abs">';
                    htms += '<section class="pivot_detail map_main_wrapper">';                
                    htms += '<h5> Equipment: </h5><span class="pivot_name">' + EquipmentName + '</span>';
                    htms += '<h5> Position: </h5><span class="pivot_degree">' + val.position + ' &deg;</span>';
                    htms += '<h5> Pressure: </h5><span class="buttonImages">' + pressureImage + '</span>';
                    htms += '<h5> Movement: </h5><span class="buttonImages">' + movementImage + '</span>';
                    htms += '<h5> ' + val.motionReasonNotes + ' </h5><span>' + val.motionReasonText + '</span>';
                    htms += '</section>';
                    htms += '<section class="buttons-abs">';
                    //htms += '<h5> ' + val.motionReasonNotes + ' </h5><span>' + val.motionReasonText + '</span>';
                    //htms += '<h5> Latitude / Longitude: </h5><span class="lat_long">' + val.Latitude + ' / ' + val.Longitude + '</span>';
                    
                    //htms += '<div class="map_buttons pull-right"> ';

                    if (val.fkDeviceID != '') {

                        if (val.EqpStatus == '1') {
                            htms += '<a data-confirm="Are you sure you want to do STOP this equipment?" href="javascript:stopEqup(' + val.pkEquipmentID + ')"> <button type="button" class="pivot_stop_btn"> Stop </button></a>';
                        } else {
                            htms += '<a data-confirm="Are you sure you want to do START this equipment?" href="equipmentmeta/create?id=' + val.pkEquipmentID +type+ '"> <button type="button" class="pivot_start_btn"> Start Pivot </button></a>';
                        }
                    }

                    htms += '<a href="pivot-summary/index?id=' + val.pkEquipmentID + '"> <button type="button" class="pivot_start_btn"> Summary </button></a>';
                    htms += '</section>';
                    htms += '</section>';
                    $('#eqpid').html(htms);
                }
            })(marker, i));
        });
    }
    function stopEqup(id) {
        $.ajax({
            url: "<?= $baseUrl ?>/map-view/stop-equip",
            method: "GET",
            data: {id: id},
            success: function() {

            }
        });
    }
    //Hide map_main_container box 
    $(document).ready(function(){
        $('body').on('click', '.close-abs', function() {
            $('.map_main_container').css('display','none')
        });
    })

</script>
