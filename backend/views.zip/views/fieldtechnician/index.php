<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchBank */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Manage Field Technician';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="pull-right margin_top20 mobile_margin field_tech_btn">
    <?= Html::a('Add/Change Accounts', ['/farm/manage'], ['class' => 'btn btn-success field_button']) ?>
    <?= Html::a('Assign Field Technician to Field', ['/field/assignfield'], ['class' => 'btn btn-success field_button']) ?>
    <?= Html::a('Assign Field to Field Technician', ['/field/assigntech'], ['class' => 'btn btn-success field_button']) ?>
    
</div>
<div class="user-index">

    <div class="page-header create_mobile_header">
        <div class="pull-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>          
    </div>
    <div class="breadcrumbs">
        <ul>
            <li><?php echo Html::a('Home', ['/site/index']); ?><i class="icon-angle-right"></i></li>
            <li><span class="readcrum_without_link">Manage Field Technician</span></li>
        </ul>
        <div class="close-bread"><a href="#"><i class="icon-remove"></i></a></div>
    </div>

    <div class="row-fluid">
        <?php \yii\widgets\Pjax::begin(['id' => 'equipment-grid']); ?>
        <div class="breadcrumbs" id="breadcrumbs-msg">

            <?php
            if ((Yii::$app->session->hasFlash('assign')) || (Yii::$app->session->hasFlash('update')) || (Yii::$app->session->hasFlash('delete')) || (Yii::$app->session->hasFlash('error')) || (Yii::$app->session->hasFlash('active')))
            {
                ?>
                <ul>
                    <?php
                    if (Yii::$app->session->getFlash('assign'))
                    {
                        echo '<li><span class="readcrum_without_link_success">' . ASSIGN_FIELD_SUCCESS . '</li>';
                    }
                    else if (Yii::$app->session->getFlash('update'))
                    {
                        echo '<li><span class="readcrum_without_link_success">' . EDIT_EQUIPMENT_SUCCESS . '</li>';
                    }
                    else if (Yii::$app->session->getFlash('delete'))
                    {
                        echo '<li><span class="readcrum_without_link_success">' . DELETE_EQUIPMENT_SUCCESS . '</li>';
                    }
                    else if (Yii::$app->session->getFlash('error'))
                    {
                        echo '<li><span class="readcrum_without_link_error">' . ASSIGN_FIELDTECH_ERROR . '</li>';
                    }
                    ?>
                </ul>
            <?php }
            ?>
        </div>
        <div class="search-form">
            <?php echo $this->render('_search', ['model' => $searchModel]); ?>
        </div><!-- search-form -->
        <div class="box box-color box-bordered">
            <div class="box-title">
                <h3><i class="icon-reorder"></i> Manage Field Technician</h3>
                <!--<a class="btn pull-right" data-toggle="modal" href="#" id = "viewAll">View All</a>-->
            </div>
            <div class="clear"></div>

            <div class="box-content nopadding">
                <?php \yii\widgets\Pjax::begin(); ?>
                <form action="" name='equipment-grid-list-form' id='equipment-grid-list-form'>
                    <div class="table-responsive">
                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'id' => 'equipment-grid',
                            'columns' => [

                                [
                                    'attribute' => 'FeildtechName',
                                    'label' => 'Field Technician Name',
                                    'value' => function ($data)
                                    {
                                        return $data->FeildtechName; // $data['name'] for array data, e.g. using SqlDataProvider.
                                    },
                                ],
                                [
                                    'attribute' => 'fieldName',
                                    'label' => 'Assigned Field Names',
                                    'value' => function ($data)
                                    {

                                        if ($data->getField($data->pkTechnicianID) == '')
                                        {
                                            return "not assigned";
                                        }
                                        else
                                        {
                                            return $data->getField($data->pkTechnicianID);
                                        }
                                    },
                                ],
                                [
                                    'attribute' => 'technicianAddDate',
                                    'label' => 'Technician Added Date',
                                    'value' => function ($data)
                                    {
                                        return date("m-d-Y", strtotime($data->technicianAddDate)); // $data['name'] for array data, e.g. using SqlDataProvider.
                                    },
                            ],
                                ],
                        ]);
                        ?>
                    </div>
                <?= Html::endForm() ?>         
                    <?php \yii\widgets\Pjax::end(); ?>
                    <?php echo common\components\PaginationField::widget(); ?>

            </div>

        </div>
</div>
    </div>
